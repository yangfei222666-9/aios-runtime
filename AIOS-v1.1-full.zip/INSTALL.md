# AIOS v1.1 安装指南

## 📦 包含内容

- **AIOS 核心系统** - 完整的 AI 操作系统
- **Perplexity Search Skill** - AI 搜索集成

## 🚀 快速开始

### 1. 解压文件

```bash
unzip AIOS-v1.1-full.zip
cd aios
```

### 2. 运行演示

```bash
python aios.py demo
```

### 3. 启动 Dashboard

```bash
python aios.py dashboard
# 访问 http://127.0.0.1:8888
```

## 🔍 Perplexity 集成

### 获取 API Key

1. 访问 https://www.perplexity.ai/settings/api
2. 注册账号（免费版可用）
3. 复制 API Key

### 设置环境变量

**Windows:**
```cmd
set PERPLEXITY_API_KEY=pplx-xxxxx
```

**Linux/Mac:**
```bash
export PERPLEXITY_API_KEY=pplx-xxxxx
```

### 测试 Perplexity

```bash
cd ../skills/perplexity-search
node test.mjs
```

### 使用 Perplexity

**方式 1：命令行**
```bash
node scripts/search.mjs "你的问题"
```

**方式 2：AIOS 任务队列**
```bash
cd ../../aios/agent_system
echo '{"id":"search_001","type":"search","message":"你的问题","priority":"normal"}' >> task_queue.jsonl
python auto_dispatcher_v2.py
```

**方式 3：语音命令**
直接说："搜索 XXX" 或 "研究 XXX"

## 📚 文档

- **AIOS 简单介绍** - `aios/AIOS_简单介绍.md`
- **AIOS 详细介绍** - `aios/AIOS_详细介绍.md`
- **Perplexity 使用指南** - `aios/PERPLEXITY_USAGE.md`
- **Perplexity Skill 文档** - `skills/perplexity-search/SKILL.md`

## 💡 系统要求

- Python 3.8+
- Node.js 18+ (仅 Perplexity Skill 需要)
- Windows / Linux / macOS

## 🆘 常见问题

### Q: Perplexity 测试失败？

A: 检查 API Key 是否设置：
```bash
echo $PERPLEXITY_API_KEY  # Linux/Mac
echo %PERPLEXITY_API_KEY%  # Windows
```

### Q: Dashboard 打不开？

A: 检查端口 8888 是否被占用：
```bash
netstat -ano | findstr :8888  # Windows
lsof -i :8888  # Linux/Mac
```

### Q: 任务不执行？

A: 查看日志：
```bash
cat aios/agent_system/dispatcher.log
```

## 📞 联系方式

- GitHub: https://github.com/yangfei222666-9/aios
- Telegram: @shh7799

---

**版本：** v1.1  
**发布日期：** 2026-02-27  
**作者：** 小九 + 珊瑚海
