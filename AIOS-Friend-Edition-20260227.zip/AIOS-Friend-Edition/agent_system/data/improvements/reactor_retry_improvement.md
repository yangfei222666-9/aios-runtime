# Reactor Retry 策略改进方案

## 当前问题
1. **没有重试机制** - 失败就失败了，不会重试
2. **验证逻辑简单** - 只检查 returncode，不验证实际效果
3. **超时固定** - 所有 playbook 都是 30s 超时
4. **没有针对性策略** - task.timeout 和其他错误用同样的处理方式

## 改进方案

### 1. 添加智能重试机制
```python
def execute_playbook_with_retry(playbook: Dict, event: Dict, max_retries: int = 3) -> Dict:
    """执行 playbook（带重试）"""
    retry_delays = [1, 2, 5]  # 指数退避：1s, 2s, 5s
    
    for attempt in range(max_retries):
        result = execute_playbook(playbook, event)
        
        if result['status'] == 'success' and result['verified']:
            return result
        
        # 如果不是最后一次尝试，等待后重试
        if attempt < max_retries - 1:
            time.sleep(retry_delays[attempt])
            print(f"  ⚠️ 重试 {attempt + 2}/{max_retries}...")
    
    return result
```

### 2. 改进验证逻辑
```python
def verify_fix(playbook: Dict, event: Dict) -> bool:
    """验证修复是否成功"""
    verify_cmd = playbook.get('action', {}).get('verify_command')
    
    if not verify_cmd:
        # 没有验证命令，默认信任 returncode
        return True
    
    try:
        proc = subprocess.run(
            verify_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )
        return proc.returncode == 0
    except:
        return False
```

### 3. 动态超时配置
```python
def get_timeout(playbook: Dict, event: Dict) -> int:
    """根据 playbook 类型和事件严重程度动态设置超时"""
    base_timeout = playbook.get('action', {}).get('timeout', 30)
    
    # 严重事件给更多时间
    severity = event.get('severity', 'INFO')
    if severity == 'CRIT':
        return base_timeout * 2
    elif severity == 'ERR':
        return base_timeout * 1.5
    
    return base_timeout
```

### 4. 针对性策略（task.timeout）
```python
def get_retry_strategy(event: Dict) -> Dict:
    """根据事件类型返回重试策略"""
    trigger = event.get('payload', {}).get('trigger')
    
    if trigger == 'task.timeout':
        return {
            'max_retries': 2,  # 超时问题重试次数少
            'retry_delays': [5, 10],  # 等待更久
            'timeout_multiplier': 2.0,  # 超时时间翻倍
            'alternative_action': 'kill_and_restart'  # 备选方案
        }
    elif trigger == 'provider.error':
        return {
            'max_retries': 3,
            'retry_delays': [1, 2, 5],
            'timeout_multiplier': 1.0,
            'alternative_action': 'provider_failover'
        }
    else:
        return {
            'max_retries': 3,
            'retry_delays': [1, 2, 5],
            'timeout_multiplier': 1.0,
            'alternative_action': None
        }
```

## 实施计划

### 立即实施（今天）
1. ✅ 添加重试机制（3 次，指数退避）
2. ✅ 动态超时配置（根据严重程度）

### 短期实施（本周）
3. 改进验证逻辑（添加 verify_command 支持）
4. 针对性策略（task.timeout 特殊处理）

### 长期优化（2 周内）
5. 备选方案机制（retry 失败后尝试 alternative_action）
6. 学习机制（记录哪些策略有效，自动调整）

## 测试用例

```python
# 测试 1：正常重试
event = {'severity': 'ERR', 'payload': {'trigger': 'provider.error'}}
playbook = {'id': 'pb1', 'action': {'command': 'echo test', 'timeout': 10}}
result = execute_playbook_with_retry(playbook, event)
assert result['status'] == 'success'

# 测试 2：task.timeout 特殊处理
event = {'severity': 'ERR', 'payload': {'trigger': 'task.timeout'}}
strategy = get_retry_strategy(event)
assert strategy['max_retries'] == 2
assert strategy['timeout_multiplier'] == 2.0

# 测试 3：动态超时
event = {'severity': 'CRIT'}
playbook = {'action': {'timeout': 30}}
timeout = get_timeout(playbook, event)
assert timeout == 60  # 30 * 2
```

## 预期效果

- **失败率：** 35.3% → <10%（通过重试）
- **响应时间：** 保持在 1-2s（动态超时不影响正常情况）
- **可靠性：** 提升 3 倍（重试 + 验证 + 备选方案）

---

**创建时间：** 2026-02-25 13:40  
**优先级：** 高  
**预计工时：** 2-3 小时
