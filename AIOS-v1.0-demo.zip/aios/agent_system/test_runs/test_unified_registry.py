"""
AIOS Unified Registry 单元测试
测试 scan_skills, classify_skill, load_old_agents, deduplicate_agents, build_unified_registry
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

# 添加父目录到 sys.path 以便导入
sys.path.insert(0, str(Path(__file__).parent.parent))

from unified_registry import (
    scan_skills,
    classify_skill,
    load_old_agents,
    deduplicate_agents,
    build_unified_registry,
)


class TestClassifySkill(unittest.TestCase):
    """测试 classify_skill 函数"""
    
    def test_monitoring_category(self):
        """测试监控类技能分类"""
        self.assertEqual(classify_skill("server-monitor", "Monitor server health"), "monitoring")
        self.assertEqual(classify_skill("resource-check", "Check resource usage"), "monitoring")
    
    def test_aios_core_category(self):
        """测试 AIOS 核心类技能分类"""
        self.assertEqual(classify_skill("aios-manager", "Manage AIOS agents"), "aios-core")
        self.assertEqual(classify_skill("self-improvement", "Agent self evaluation"), "aios-core")
        self.assertEqual(classify_skill("data-collector", "Collect quality data"), "aios-core")
    
    def test_development_category(self):
        """测试开发类技能分类"""
        self.assertEqual(classify_skill("git-helper", "Git operations"), "development")
        self.assertEqual(classify_skill("docker-manager", "Docker container management"), "development")
        self.assertEqual(classify_skill("skill-creator", "Create new skills"), "development")
    
    def test_automation_category(self):
        """测试自动化类技能分类"""
        self.assertEqual(classify_skill("workflow-automation", "Automate workflows"), "automation")
        self.assertEqual(classify_skill("file-organizer", "Organize files automatically"), "automation")
    
    def test_other_category(self):
        """测试其他类别"""
        self.assertEqual(classify_skill("random-skill", "Some random functionality"), "other")


class TestScanSkills(unittest.TestCase):
    """测试 scan_skills 函数"""
    
    def setUp(self):
        """创建临时技能目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.skills_dir = Path(self.temp_dir) / "skills"
        self.skills_dir.mkdir()
        
        # 创建测试技能目录
        skill1 = self.skills_dir / "test-skill-1"
        skill1.mkdir()
        (skill1 / "SKILL.md").write_text(
            "---\ndescription: 'Test skill one'\n---\n# Test Skill",
            encoding="utf-8"
        )
        (skill1 / "main.py").write_text("# Python script", encoding="utf-8")
        
        skill2 = self.skills_dir / "test-skill-2"
        skill2.mkdir()
        (skill2 / "SKILL.md").write_text(
            "# Test Skill 2\nNo frontmatter",
            encoding="utf-8"
        )
    
    def tearDown(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    @patch('unified_registry.SKILLS_DIR')
    def test_scan_skills_basic(self, mock_skills_dir):
        """测试基本技能扫描"""
        mock_skills_dir.__iter__ = lambda x: iter([
            self.skills_dir / "test-skill-1",
            self.skills_dir / "test-skill-2"
        ])
        mock_skills_dir.iterdir.return_value = [
            self.skills_dir / "test-skill-1",
            self.skills_dir / "test-skill-2"
        ]
        
        skills = scan_skills()
        
        self.assertIn("test-skill-1", skills)
        self.assertEqual(skills["test-skill-1"]["description"], "Test skill one")
        self.assertTrue(skills["test-skill-1"]["has_script"])
        self.assertIn("main.py", skills["test-skill-1"]["scripts"])
        
        self.assertIn("test-skill-2", skills)
        self.assertEqual(skills["test-skill-2"]["description"], "")
        self.assertFalse(skills["test-skill-2"]["has_script"])


class TestLoadOldAgents(unittest.TestCase):
    """测试 load_old_agents 函数"""
    
    def setUp(self):
        """创建临时 agent 文件"""
        self.temp_dir = tempfile.mkdtemp()
        
        self.agents_json = Path(self.temp_dir) / "agents.json"
        self.agents_data_json = Path(self.temp_dir) / "agents_data.json"
        self.data_agents_json = Path(self.temp_dir) / "data" / "agents.json"
        self.data_agents_json.parent.mkdir(parents=True, exist_ok=True)
        
        # 创建测试数据
        self.agents_json.write_text(json.dumps({
            "agents": [
                {"id": "agent-1", "name": "Agent One", "type": "skill-based"}
            ]
        }), encoding="utf-8")
        
        self.agents_data_json.write_text(json.dumps({
            "agents": [
                {"id": "agent-2", "name": "Agent Two", "type": "general"},
                {"id": "agent-1", "name": "Agent One Updated", "type": "skill-based"}
            ]
        }), encoding="utf-8")
        
        self.data_agents_json.write_text(json.dumps({
            "agents": [
                {"id": "agent-3", "name": "Agent Three", "type": "dispatcher"}
            ]
        }), encoding="utf-8")
    
    def tearDown(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    @patch('unified_registry.OLD_AGENTS_JSON')
    @patch('unified_registry.OLD_AGENTS_DATA')
    @patch('unified_registry.OLD_DATA_AGENTS')
    def test_load_old_agents_merge(self, mock_data_agents, mock_agents_data, mock_agents_json):
        """测试加载和合并旧 agent 数据"""
        mock_agents_json.exists.return_value = True
        mock_agents_json.read_text.return_value = self.agents_json.read_text()
        
        mock_agents_data.exists.return_value = True
        mock_agents_data.read_text.return_value = self.agents_data_json.read_text()
        
        mock_data_agents.exists.return_value = True
        mock_data_agents.read_text.return_value = self.data_agents_json.read_text()
        
        agents = load_old_agents()
        
        # 应该有 3 个 agent（agent-1 被覆盖）
        self.assertEqual(len(agents), 3)
        self.assertIn("agent-1", agents)
        self.assertIn("agent-2", agents)
        self.assertIn("agent-3", agents)
        
        # agent-1 应该是最后加载的版本（来自 agents_data.json）
        self.assertEqual(agents["agent-1"]["name"], "Agent One Updated")


class TestDeduplicateAgents(unittest.TestCase):
    """测试 deduplicate_agents 函数"""
    
    def test_deduplicate_by_skill_path(self):
        """测试基于 skill_path 的去重"""
        agents = {
            "agent-1": {
                "id": "agent-1",
                "name": "Skill Agent 1",
                "skill_path": "/skills/test-skill",
                "stats": {"tasks_completed": 10}
            },
            "agent-2": {
                "id": "agent-2",
                "name": "Skill Agent 2",
                "skill_path": "/skills/test-skill",
                "stats": {"tasks_completed": 5}
            },
            "agent-3": {
                "id": "agent-3",
                "name": "Different Skill",
                "skill_path": "/skills/other-skill",
                "stats": {"tasks_completed": 3}
            }
        }
        
        kept, archived = deduplicate_agents(agents)
        
        # agent-1 应该被保留（更高的 tasks_completed）
        self.assertIn("agent-1", kept)
        self.assertNotIn("agent-2", kept)
        self.assertIn("agent-2", archived)
        
        # agent-3 应该被保留（不同的 skill）
        self.assertIn("agent-3", kept)
    
    def test_deduplicate_by_task_types(self):
        """测试基于 task_types 的去重"""
        agents = {
            "agent-1": {
                "id": "agent-1",
                "name": "Task Agent 1",
                "task_types": ["coding", "testing"],
                "stats": {"tasks_completed": 20, "success_rate": 0.9}
            },
            "agent-2": {
                "id": "agent-2",
                "name": "Task Agent 2",
                "task_types": ["coding", "testing"],
                "stats": {"tasks_completed": 10, "success_rate": 0.8}
            }
        }
        
        kept, archived = deduplicate_agents(agents)
        
        # agent-1 应该被保留（更高的分数）
        self.assertIn("agent-1", kept)
        self.assertIn("agent-2", archived)
    
    def test_no_duplicates(self):
        """测试没有重复的情况"""
        agents = {
            "agent-1": {"id": "agent-1", "name": "Agent 1", "type": "type-a"},
            "agent-2": {"id": "agent-2", "name": "Agent 2", "type": "type-b"},
        }
        
        kept, archived = deduplicate_agents(agents)
        
        self.assertEqual(len(kept), 2)
        self.assertEqual(len(archived), 0)


class TestBuildUnifiedRegistry(unittest.TestCase):
    """测试 build_unified_registry 函数"""
    
    def test_build_registry_structure(self):
        """测试注册表结构"""
        skills = {
            "test-skill": {
                "name": "test-skill",
                "path": "/skills/test-skill",
                "description": "Test skill",
                "has_script": True,
                "scripts": ["main.py"],
                "category": "development"
            }
        }
        
        kept_agents = {
            "agent-1": {
                "id": "agent-1",
                "name": "Test Agent",
                "template": "general",
                "goal": "Test goal",
                "skills": ["test-skill"],
                "stats": {"tasks_completed": 5}
            }
        }
        
        archived_agents = {
            "agent-2": {
                "id": "agent-2",
                "name": "Archived Agent",
                "_archive_reason": "Duplicate"
            }
        }
        
        registry = build_unified_registry(skills, kept_agents, archived_agents)
        
        # 检查基本结构
        self.assertEqual(registry["version"], "1.0")
        self.assertIn("updated_at", registry)
        self.assertIn("skills", registry)
        self.assertIn("agents", registry)
        self.assertIn("stats", registry)
        self.assertIn("categories", registry)
        
        # 检查统计数据
        self.assertEqual(registry["stats"]["total_skills"], 1)
        self.assertEqual(registry["stats"]["total_agents_active"], 1)
        self.assertEqual(registry["stats"]["total_agents_archived"], 1)
        
        # 检查 agents 结构
        self.assertIn("active", registry["agents"])
        self.assertIn("archived", registry["agents"])
        self.assertIn("agent-1", registry["agents"]["active"])
        self.assertIn("agent-2", registry["agents"]["archived"])
        
        # 检查分类
        self.assertIn("development", registry["categories"])
        self.assertIn("test-skill", registry["categories"]["development"])
    
    def test_skill_path_inference(self):
        """测试从 skill_path 推断技能"""
        skills = {}
        
        kept_agents = {
            "agent-1": {
                "id": "agent-1",
                "name": "Agent with skill_path",
                "skill_path": "/skills/inferred-skill",
                "skills": []
            }
        }
        
        archived_agents = {}
        
        registry = build_unified_registry(skills, kept_agents, archived_agents)
        
        # 检查技能是否被推断并添加
        self.assertIn("inferred-skill", registry["agents"]["active"]["agent-1"]["skills"])


if __name__ == "__main__":
    unittest.main()
