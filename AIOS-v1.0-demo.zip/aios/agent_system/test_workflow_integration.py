"""
测试工作流集成
"""

import json
from pathlib import Path
from auto_dispatcher import AutoDispatcher

def test_workflow_integration():
    """测试工作流集成"""
    workspace = Path("C:/Users/A/.openclaw/workspace")
    dispatcher = AutoDispatcher(workspace)
    
    print("=== 工作流集成测试 ===\n")
    
    # 检查工作流引擎
    if not dispatcher.workflow_engine:
        print("[X] 工作流引擎未加载")
        return
    
    print("[OK] 工作流引擎已加载")
    print(f"   已加载工作流: {len(dispatcher.workflow_engine.workflows)}")
    for wf_id, wf in dispatcher.workflow_engine.workflows.items():
        print(f"   - {wf_id}: {wf['description']}")
    print()
    
    # 模拟一个代码任务
    test_task = {
        "id": "test-workflow-001",
        "type": "code",
        "priority": "normal",
        "description": "实现一个简单的缓存装饰器",
        "enqueued_at": "2026-02-26T03:30:00"
    }
    
    print("=== 模拟任务分发 ===")
    print(f"任务ID: {test_task['id']}")
    print(f"任务类型: {test_task['type']}")
    print(f"优先级: {test_task['priority']}")
    print()
    
    # 获取 coder 工作流
    workflow = dispatcher.workflow_engine.get_workflow("coder")
    if workflow:
        print("[OK] 找到 coder 工作流")
        print(f"   工作流ID: {workflow['workflow_id']}")
        print(f"   描述: {workflow['description']}")
        print(f"   阶段数: {len(workflow['stages'])}")
        print(f"   回滚: {workflow.get('rollback_on_failure', False)}")
        print()
        
        print("=== 工作流阶段 ===")
        for i, stage in enumerate(workflow["stages"], 1):
            print(f"{i}. {stage['name']} ({stage['stage']})")
            print(f"   动作: {', '.join(stage['actions'][:3])}")
            print(f"   输出: {stage['output']}")
        print()
        
        print("=== 质量门控 ===")
        for gate, value in workflow.get("quality_gates", {}).items():
            print(f"- {gate}: {value}")
        print()
    
    # 测试启动工作流
    try:
        execution_id = dispatcher.workflow_engine.start_execution(
            agent_id="coder-dispatcher",
            agent_type="coder",
            task=test_task
        )
        print(f"[OK] 工作流已启动")
        print(f"   执行ID: {execution_id}")
        print()
        
        # 查看执行状态
        execution = dispatcher.workflow_engine.get_execution_status(execution_id)
        if execution:
            print("=== 执行状态 ===")
            print(f"状态: {execution['status']}")
            print(f"当前阶段: {execution['current_stage']}/{len(workflow['stages'])}")
            print(f"已完成: {len(execution['stages_completed'])}")
            print(f"失败: {len(execution['stages_failed'])}")
            print()
        
        # 模拟完成第一阶段
        print("=== 模拟阶段执行 ===")
        stage1_output = {
            "requirements": [
                "实现缓存装饰器",
                "支持 TTL 过期",
                "支持 LRU 淘汰",
                "线程安全"
            ]
        }
        result = dispatcher.workflow_engine.execute_stage(execution_id, stage1_output)
        print(f"阶段1完成: {result['status']}")
        if result['status'] == 'continue':
            next_stage = result['next_stage']
            print(f"下一阶段: {next_stage['name']} ({next_stage['stage']})")
        print()
        
    except Exception as e:
        print(f"[X] 工作流启动失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_workflow_integration()
