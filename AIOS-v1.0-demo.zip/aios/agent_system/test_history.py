"""测试 TeamOrchestration + ExecutionHistory"""
from team_orchestration import TeamOrchestration

team = TeamOrchestration('agents.json')

# 执行任务
print("=== 执行任务 ===")
result = team.execute('检查系统健康')
print(f"Success: {result['success']}")
print(f"Time: {result['total_time']:.2f}s")

# 查看历史
print("\n=== 查看历史 ===")
history = team.get_history(limit=3)
print(f"历史记录: {len(history)} 条")
for i, record in enumerate(history, 1):
    print(f"  {i}. {record['user_input']} (成功: {record['success']}, 耗时: {record['duration']:.2f}s)")

# 统计信息
print("\n=== 统计信息 ===")
stats = team.get_stats()
print(f"总执行: {stats['total']}")
print(f"成功: {stats['success']}")
print(f"失败: {stats['failed']}")
print(f"成功率: {stats['success_rate']}%")
print(f"平均耗时: {stats['avg_duration']}s")
print(f"总步骤: {stats['total_steps']}")

# 搜索历史
print("\n=== 搜索历史 ===")
results = team.search_history(user_input="健康", success=True)
print(f"搜索结果: {len(results)} 条")
