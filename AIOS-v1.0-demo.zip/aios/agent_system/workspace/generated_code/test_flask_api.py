# 测试 Flask API
import requests
import time
import subprocess
import sys

# 启动 Flask 服务器（后台）
print("🚀 启动 Flask 服务器...")
process = subprocess.Popen(
    [sys.executable, "generated_20260226_052935.py"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE
)

# 等待服务器启动
time.sleep(3)

try:
    # 测试 GET /time
    print("\n📡 测试 GET /time")
    response = requests.get("http://localhost:5000/time")
    print(f"状态码: {response.status_code}")
    print(f"响应: {response.json()}")
    
    # 测试 POST /calculate
    print("\n📡 测试 POST /calculate")
    response = requests.post(
        "http://localhost:5000/calculate",
        json={"num1": 10, "num2": 20}
    )
    print(f"状态码: {response.status_code}")
    print(f"响应: {response.json()}")
    
    print("\n✅ 所有测试通过！")
    
finally:
    # 关闭服务器
    print("\n🛑 关闭服务器...")
    process.terminate()
    process.wait()
