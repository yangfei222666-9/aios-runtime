"""
完整工作流系统测试
测试：进度追踪 + Dashboard + 质量门控
"""

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))

from workflow_engine import WorkflowEngine
from workflow_progress import WorkflowProgressTracker
from quality_gate_validator import QualityGateValidator


def test_complete_workflow():
    """测试完整工作流"""
    workspace = Path("C:/Users/A/.openclaw/workspace")
    
    # 初始化组件
    engine = WorkflowEngine(workspace=workspace)
    tracker = WorkflowProgressTracker(workspace)
    validator = QualityGateValidator(workspace)
    
    print("=== 完整工作流测试 ===\n")
    
    # 1. 启动工作流
    print("1. 启动工作流")
    execution_id = engine.start_execution(
        agent_id="coder-dispatcher",
        agent_type="coder",
        task={"description": "实现缓存装饰器"}
    )
    print(f"   执行ID: {execution_id}\n")
    
    # 2. 执行阶段1：理解需求
    print("2. 执行阶段1：理解需求")
    tracker.report_stage_start(execution_id, "1_understand", "coder-dispatcher")
    tracker.report_stage_progress(execution_id, "1_understand", 0.5, "正在分析需求...")
    
    stage1_output = {
        "requirements": ["支持TTL", "支持LRU", "线程安全"]
    }
    stage1_metrics = {
        "duration_sec": 5.2
    }
    
    tracker.report_stage_complete(execution_id, "1_understand", stage1_output, stage1_metrics)
    result1 = engine.execute_stage(execution_id, stage1_output)  # 第一阶段不需要质量门控
    print(f"   状态: {result1['status']}")
    if result1['status'] == 'continue':
        print(f"   下一阶段: {result1['next_stage']['name']}\n")
    else:
        print(f"   工作流已完成\n")
        return
    
    # 3. 执行阶段2：设计方案
    print("3. 执行阶段2：设计方案")
    tracker.report_stage_start(execution_id, "2_design", "coder-dispatcher")
    
    stage2_output = {
        "design": "使用 functools.lru_cache + TTL 扩展"
    }
    stage2_metrics = {
        "duration_sec": 8.5
    }
    
    tracker.report_stage_complete(execution_id, "2_design", stage2_output, stage2_metrics)
    result2 = engine.execute_stage(execution_id, stage2_output)
    print(f"   状态: {result2['status']}")
    if result2['status'] == 'continue':
        print(f"   下一阶段: {result2['next_stage']['name']}\n")
    else:
        print(f"   工作流已完成\n")
        return
    
    # 4. 执行阶段3：编写代码
    print("4. 执行阶段3：编写代码")
    tracker.report_stage_start(execution_id, "3_implement", "coder-dispatcher")
    
    stage3_output = {
        "code": "def cache_with_ttl(ttl=60): ..."
    }
    stage3_metrics = {
        "duration_sec": 15.3,
        "lines_of_code": 45
    }
    
    tracker.report_stage_complete(execution_id, "3_implement", stage3_output, stage3_metrics)
    result3 = engine.execute_stage(execution_id, stage3_output)
    print(f"   状态: {result3['status']}")
    if result3['status'] == 'continue':
        print(f"   下一阶段: {result3['next_stage']['name']}\n")
    else:
        print(f"   工作流已完成\n")
        return
    
    # 5. 执行阶段4：测试验证（带质量门控）
    print("5. 执行阶段4：测试验证（带质量门控）")
    tracker.report_stage_start(execution_id, "4_test", "coder-dispatcher")
    
    stage4_output = {
        "tests": "test_cache.py"
    }
    stage4_metrics = {
        "duration_sec": 12.1,
        "test_coverage": 0.85,      # 通过（>= 0.8）
        "complexity": 8,             # 通过（<= 10）
        "security_issues": 0         # 通过（== 0）
    }
    
    tracker.report_stage_complete(execution_id, "4_test", stage4_output, stage4_metrics)
    result4 = engine.execute_stage(execution_id, stage4_output, stage4_metrics)
    print(f"   状态: {result4['status']}")
    
    if result4.get('validation'):
        validation = result4['validation']
        print(f"   质量门控: {'✓ 通过' if validation['passed'] else '✗ 失败'}")
        for gate, detail in validation['details'].items():
            print(f"     {gate}: {detail['message']}")
    
    if result4['status'] == 'continue':
        print(f"   下一阶段: {result4['next_stage']['name']}\n")
    else:
        print(f"   工作流已完成或失败\n")
        return
    
    # 6. 执行阶段5：代码审查
    print("6. 执行阶段5：代码审查")
    tracker.report_stage_start(execution_id, "5_review", "coder-dispatcher")
    
    stage5_output = {
        "review": "代码质量良好，建议添加更多边界测试"
    }
    stage5_metrics = {
        "duration_sec": 6.8
    }
    
    tracker.report_stage_complete(execution_id, "5_review", stage5_output, stage5_metrics)
    result5 = engine.execute_stage(execution_id, stage5_output, stage5_metrics)
    print(f"   状态: {result5['status']}\n")
    
    # 7. 查看最终进度
    print("7. 查看最终进度")
    progress = tracker.get_execution_progress(execution_id)
    print(f"   总阶段: {progress['total_stages']}")
    print(f"   已完成: {progress['completed_stages']}")
    print(f"   失败: {progress['failed_stages']}\n")
    
    # 8. 查看质量门控通过率
    print("8. 查看质量门控通过率")
    pass_rate = validator.get_pass_rate("coder-standard")
    print(f"   coder-standard 通过率: {pass_rate:.1%}\n")
    
    print("=== 测试完成 ===")


if __name__ == "__main__":
    test_complete_workflow()
