# AIOS Agent System - 心跳模式说明

## 📦 文件结构

```
agent_system/
├── heartbeat_demo.py    # Demo 模式（快速测试）
├── heartbeat_full.py    # Full 模式（生产环境）
├── demo.ps1             # Demo 模式快捷脚本
├── prod.ps1             # Full 模式快捷脚本
├── task_queue.jsonl     # 任务队列
└── execution_log.jsonl  # 执行日志（Demo 模式）
```

## 🎯 两种模式

### Demo 模式 - 快速测试
**用途：** 开发测试、功能验证、演示展示

**特点：**
- ✅ 直接模拟执行，秒级反馈
- ✅ 清晰的任务执行日志
- ✅ 无需 OpenClaw，独立运行
- ✅ 适合日常开发和演示

**使用：**
```bash
# 方式1：直接运行
python heartbeat_demo.py

# 方式2：快捷脚本
.\demo.ps1
```

**输出示例：**
```
🚀 AIOS Heartbeat Started
📋 处理任务队列...
  本次处理 3 个任务
  [1/3] 执行 code 任务 (优先级: high)
      ✅ Coder Agent 完成代码任务: 重构 scheduler.py
  [2/3] 执行 analysis 任务 (优先级: normal)
      ✅ Analyst Agent 完成分析任务: 分析失败事件
  [3/3] 执行 monitor 任务 (优先级: low)
      ✅ Monitor Agent 完成监控任务: 检查磁盘使用率
✅ Heartbeat Completed
```

---

### Full 模式 - 生产环境
**用途：** 生产部署、真实任务执行

**特点：**
- ✅ 创建 spawn 请求
- ✅ 通过 OpenClaw 执行真实 Agent
- ✅ 完整的任务生命周期管理
- ✅ 适合生产环境

**使用：**
```bash
# 方式1：直接运行
python heartbeat_full.py

# 方式2：快捷脚本
.\prod.ps1

# 方式3：集成到 OpenClaw 心跳
# 在 HEARTBEAT.md 中配置
```

---

## 📝 创建任务

**任务格式（task_queue.jsonl）：**
```json
{"type": "code", "description": "重构 scheduler.py", "priority": "high"}
{"type": "analysis", "description": "分析失败事件", "priority": "normal"}
{"type": "monitor", "description": "检查磁盘使用率", "priority": "low"}
```

**任务类型：**
- `code` → Coder Agent
- `analysis` → Analyst Agent
- `monitor` → Monitor Agent
- `research` → Researcher Agent
- `design` → Designer Agent

**优先级：**
- `high` - 高优先级
- `normal` - 普通优先级
- `low` - 低优先级

---

## 🚀 快速开始

### 1. 创建测试任务
```bash
cat > task_queue.jsonl << EOF
{"type": "code", "description": "优化性能", "priority": "high"}
{"type": "analysis", "description": "分析数据", "priority": "normal"}
EOF
```

### 2. 运行 Demo 模式
```bash
.\demo.ps1
```

### 3. 查看执行日志
```bash
cat execution_log.jsonl
```

---

## 📊 对比表

| 特性 | Demo 模式 | Full 模式 |
|------|-----------|-----------|
| 执行方式 | 模拟执行 | 真实 Agent |
| 速度 | 快（0.5s/任务） | 慢（需启动 Agent） |
| 依赖 | 无 | OpenClaw |
| 日志 | execution_log.jsonl | spawn_requests.jsonl |
| 适用场景 | 开发测试 | 生产环境 |

---

## 💡 最佳实践

1. **日常开发** - 用 Demo 模式快速测试
2. **功能验证** - 用 Demo 模式验证逻辑
3. **演示展示** - 用 Demo 模式展示流程
4. **生产部署** - 用 Full 模式真实执行
5. **集成测试** - 用 Full 模式测试完整流程

---

**版本：** v3.6  
**最后更新：** 2026-02-26  
**维护者：** 小九 + 珊瑚海
