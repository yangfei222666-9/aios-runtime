#!/usr/bin/env python3
"""
测试 ReleaseManager Agent
"""
import pytest
import json
import shutil
from pathlib import Path
from release_manager import ReleaseManager, RELEASES_DIR, VERSION_FILE

# 测试用的临时项目目录
TEST_PROJECT = Path(__file__).parent / "test_project"


@pytest.fixture
def setup_test_project():
    """创建测试项目"""
    TEST_PROJECT.mkdir(exist_ok=True)
    
    # 创建必需文件
    (TEST_PROJECT / "aram_helper.py").write_text("# Test", encoding="utf-8")
    (TEST_PROJECT / "aram_data.json").write_text("{}", encoding="utf-8")
    (TEST_PROJECT / "README.md").write_text("# Test", encoding="utf-8")
    (TEST_PROJECT / "启动提示器.bat").write_text("@echo off", encoding="utf-8")
    
    yield TEST_PROJECT
    
    # 清理
    if TEST_PROJECT.exists():
        shutil.rmtree(TEST_PROJECT)


def test_load_version():
    """测试加载版本"""
    manager = ReleaseManager()
    version = manager.current_version
    
    assert "major" in version
    assert "minor" in version
    assert "patch" in version
    assert "tag" in version


def test_bump_version():
    """测试递增版本号"""
    manager = ReleaseManager()
    
    # Patch
    v1 = manager._bump_version("patch")
    assert v1["patch"] == manager.current_version["patch"] + 1
    
    # Minor
    v2 = manager._bump_version("minor")
    assert v2["minor"] == manager.current_version["minor"] + 1
    assert v2["patch"] == 0
    
    # Major
    v3 = manager._bump_version("major")
    assert v3["major"] == manager.current_version["major"] + 1
    assert v3["minor"] == 0
    assert v3["patch"] == 0


def test_check_quality_gates():
    """测试质量门禁"""
    manager = ReleaseManager()
    
    passed, failures = manager.check_quality_gates()
    
    # 应该检查必需文件
    assert isinstance(passed, bool)
    assert isinstance(failures, list)


def test_build_release_package():
    """测试构建发布包"""
    manager = ReleaseManager()
    
    version = {
        "major": 1,
        "minor": 0,
        "patch": 0,
        "build": 1,
        "tag": "v1.0.0-test"
    }
    
    # 注意：这个测试需要真实的项目文件
    # 如果文件不存在，会失败（预期行为）
    zip_path = manager.build_release_package(version)
    
    if zip_path:
        assert zip_path.exists()
        assert zip_path.suffix == ".zip"
        # 清理
        zip_path.unlink()


def test_generate_release_notes():
    """测试生成发布说明"""
    manager = ReleaseManager()
    
    version = {
        "major": 1,
        "minor": 0,
        "patch": 0,
        "tag": "v1.0.0"
    }
    
    notes = manager._generate_release_notes(version)
    
    assert "ARAM Helper" in notes
    assert version["tag"] in notes
    assert "使用方法" in notes


def test_integration_check_build():
    """集成测试：检查 + 构建"""
    manager = ReleaseManager()
    
    # 1. 检查质量门禁
    passed, failures = manager.check_quality_gates()
    print(f"质量门禁: {'通过' if passed else '未通过'}")
    if not passed:
        for failure in failures:
            print(f"  - {failure}")
    
    # 2. 如果通过，尝试构建
    if passed:
        version = manager._bump_version("patch")
        zip_path = manager.build_release_package(version)
        
        if zip_path:
            print(f"✅ 构建成功: {zip_path.name}")
            assert zip_path.exists()
            # 清理
            zip_path.unlink()
        else:
            print("❌ 构建失败")


if __name__ == "__main__":
    # 运行测试
    pytest.main([__file__, "-v", "-s"])
