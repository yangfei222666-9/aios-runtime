"""
直接测试工作流系统（不通过 sessions_spawn）
"""
from pathlib import Path
from workflow_engine import WorkflowEngine
from workflow_progress import WorkflowProgressTracker
from quality_gate_validator import QualityGateValidator

workspace = Path("C:/Users/A/.openclaw/workspace")

# 初始化
engine = WorkflowEngine(workspace=workspace)
tracker = WorkflowProgressTracker(workspace)
validator = QualityGateValidator(workspace)

print("=== 工作流系统测试 ===\n")

# 测试1: Coder 工作流
print("1. 测试 Coder 工作流")
execution_id = engine.start_execution(
    agent_id="coder-dispatcher",
    agent_type="coder",
    task={"description": "实现LRU缓存类"}
)
print(f"   执行ID: {execution_id}")

# 模拟完成5个阶段
stages = [
    ("1_understand", {"requirements": ["LRU算法", "get/put操作", "容量限制"]}),
    ("2_design", {"design": "使用OrderedDict实现"}),
    ("3_implement", {"code": "class LRUCache: ..."}),
    ("4_test", {"tests": "test_lru_cache.py"}),
    ("5_review", {"review": "代码质量良好"})
]

for stage_id, output in stages:
    tracker.report_stage_start(execution_id, stage_id, "coder-dispatcher")
    tracker.report_stage_complete(execution_id, stage_id, output)
    
    # 第4阶段验证质量门控
    if stage_id == "4_test":
        metrics = {
            "test_coverage": 0.85,
            "complexity": 8,
            "security_issues": 0
        }
        result = engine.execute_stage(execution_id, output, metrics)
    else:
        result = engine.execute_stage(execution_id, output)
    
    print(f"   阶段 {stage_id}: {result['status']}")

print(f"   ✓ Coder 工作流完成\n")

# 测试2: Analyst 工作流
print("2. 测试 Analyst 工作流")
execution_id2 = engine.start_execution(
    agent_id="analyst-dispatcher",
    agent_type="analyst",
    task={"description": "分析错误趋势"}
)
print(f"   执行ID: {execution_id2}")

# 只完成前3个阶段
analyst_stages = [
    ("1_collect", {"data_points": 150}),
    ("2_clean", {"cleaned_records": 145}),
    ("3_analyze", {"top_errors": ["ConnectionTimeout", "FileNotFound"]})
]

for stage_id, output in analyst_stages:
    tracker.report_stage_start(execution_id2, stage_id, "analyst-dispatcher")
    tracker.report_stage_complete(execution_id2, stage_id, output)
    result = engine.execute_stage(execution_id2, output)
    print(f"   阶段 {stage_id}: {result['status']}")

print(f"   ✓ Analyst 工作流部分完成\n")

# 查看统计
print("3. 工作流统计")
all_executions = engine.list_executions()
print(f"   总执行数: {len(all_executions)}")
print(f"   运行中: {len([e for e in all_executions if e['status'] == 'running'])}")
print(f"   已完成: {len([e for e in all_executions if e['status'] == 'completed'])}")

# 查看质量门控通过率
pass_rate = validator.get_pass_rate("coder-standard")
print(f"   Coder 质量门控通过率: {pass_rate:.1%}")

print("\n=== 测试完成 ===")
