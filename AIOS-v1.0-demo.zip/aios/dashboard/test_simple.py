"""最简化 SSE 测试服务器"""
import json
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

class SimpleSSEHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/metrics/stream':
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Connection', 'keep-alive')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            try:
                counter = 0
                while True:
                    data = {
                        'active_agents': 5,
                        'evolution_score': 0.45,
                        'today_improvements': 3,
                        'success_rate': 85,
                        'resources': {
                            'cpu': 25,
                            'mem': 60,
                            'disk': 45,
                            'gpu': 30
                        },
                        'agents': [
                            {'name': 'Coder', 'pid': 12345, 'alive': True, 'status': 'active', 'success_rate': 90, 'last_active': time.time()},
                            {'name': 'Analyst', 'pid': 12346, 'alive': True, 'status': 'active', 'success_rate': 85, 'last_active': time.time()},
                            {'name': 'Monitor', 'pid': 12347, 'alive': True, 'status': 'active', 'success_rate': 95, 'last_active': time.time()},
                            {'name': 'Researcher', 'pid': 12348, 'alive': False, 'status': 'idle', 'success_rate': 75, 'last_active': time.time() - 3600},
                        ],
                        'top_errors': [
                            {'error': 'Connection timeout', 'count': 5},
                            {'error': 'File not found', 'count': 3},
                            {'error': 'Permission denied', 'count': 2},
                        ],
                        'slow_ops': [
                            {'operation': 'Database query', 'duration': 1500},
                            {'operation': 'API call', 'duration': 1200},
                            {'operation': 'File processing', 'duration': 800},
                        ],
                        'counter': counter
                    }
                    
                    message = f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
                    self.wfile.write(message.encode('utf-8'))
                    self.wfile.flush()
                    
                    counter += 1
                    time.sleep(3)
                    
            except (BrokenPipeError, ConnectionResetError):
                pass
        
        elif self.path == '/' or self.path == '/index.html':
            dashboard_file = Path(__file__).parent / "index.html"
            if dashboard_file.exists():
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                with open(dashboard_file, 'rb') as f:
                    self.wfile.write(f.read())
            else:
                self.send_error(404)
        else:
            self.send_error(404)
    
    def log_message(self, format, *args):
        if '/api/metrics/stream' not in format:
            print(f"[{self.address_string()}] {format % args}")

if __name__ == "__main__":
    PORT = 8080
    print("=" * 60)
    print(f"🚀 简化版 Dashboard 启动: http://localhost:{PORT}")
    print("=" * 60)
    
    httpd = HTTPServer(('', PORT), SimpleSSEHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n⏹️  服务器已停止")
