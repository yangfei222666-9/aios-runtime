"""
测试 SSE Dashboard 功能
"""
import time
import json
from pathlib import Path

# 模拟写入一些测试数据到 metrics
def test_metrics():
    """测试 metrics 数据"""
    print("📊 测试 Metrics 数据...")
    
    try:
        from aios.observability.metrics import METRICS
        
        # 模拟一些操作
        METRICS.increment('tasks.total', 10)
        METRICS.increment('tasks.success', 8)
        METRICS.increment('tasks.failed', 2)
        METRICS.set_gauge('queue.size', 5)
        METRICS.set_gauge('active.workers', 3)
        
        print("✅ Metrics 数据已更新")
        print(json.dumps(METRICS.snapshot(), indent=2, ensure_ascii=False))
        
    except ImportError:
        print("⚠️  AIOS metrics 模块未找到，使用模拟数据")


def test_events():
    """测试 events 数据"""
    print("\n📡 测试 Events 数据...")
    
    events_file = Path(__file__).parent.parent.parent / "events.jsonl"
    
    # 写入一些测试事件
    test_events = [
        {"timestamp": time.time(), "level": "info", "message": "系统启动"},
        {"timestamp": time.time(), "level": "info", "message": "Dashboard 连接成功"},
        {"timestamp": time.time(), "level": "warning", "message": "CPU 使用率较高"},
        {"timestamp": time.time(), "level": "error", "message": "任务执行失败"},
        {"timestamp": time.time(), "level": "info", "message": "数据同步完成"},
    ]
    
    try:
        with open(events_file, 'a', encoding='utf-8') as f:
            for event in test_events:
                f.write(json.dumps(event, ensure_ascii=False) + '\n')
        
        print(f"✅ 已写入 {len(test_events)} 条测试事件到 {events_file}")
        
    except Exception as e:
        print(f"❌ 写入事件失败: {e}")


def main():
    print("=" * 60)
    print("🧪 AIOS Dashboard SSE 功能测试")
    print("=" * 60)
    print()
    
    test_metrics()
    test_events()
    
    print("\n" + "=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)
    print("\n💡 提示：")
    print("1. 运行 start_sse_dashboard.bat 启动服务器")
    print("2. 访问 http://localhost:8080 查看 Dashboard")
    print("3. 观察数据是否实时更新")
    print()


if __name__ == "__main__":
    main()
