"""测试 SSE 连接"""
import urllib.request
import time

url = 'http://localhost:8888/api/metrics/stream'

print(f"连接到 {url}...")
try:
    response = urllib.request.urlopen(url, timeout=10)
    print("✅ SSE 连接成功！")
    print("接收数据中（5秒）...\n")
    
    start = time.time()
    while time.time() - start < 5:
        line = response.readline().decode('utf-8')
        if line.strip():
            print(line.strip())
    
    print("\n✅ SSE 数据正常推送！")
    
except Exception as e:
    print(f"❌ SSE 连接失败: {e}")
