"""
AIOS v1.3 简化端到端测试
直接测试三大模块的核心功能
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from planner import Planner
from memory import MemoryManager
from tools import ToolManager

print("=" * 60)
print("AIOS v1.3 端到端测试")
print("=" * 60)

workspace = Path(__file__).parent.parent

# 1. 测试 Planning
print("\n[1/3] 测试 Planning 模块")
print("-" * 60)
planner = Planner(workspace)
task = "帮我规划一次周末去京都的旅行"
plan = planner.plan(task)

print(f"✅ 任务拆解成功")
print(f"   原始任务: {task}")
print(f"   子任务数: {len(plan.subtasks)}")
print(f"   执行策略: {plan.strategy}")
print(f"\n   子任务列表:")
for i, subtask in enumerate(plan.subtasks, 1):
    print(f"   {i}. {subtask.description} ({subtask.type})")

# 2. 测试 Memory
print(f"\n[2/3] 测试 Memory 模块")
print("-" * 60)
memory = MemoryManager(workspace)

# 存储记忆
memory.store("之前规划过去京都的旅行，预算是5000元", importance=0.8)
memory.store("京都的主要景点有清水寺和金阁寺", importance=0.7)

# 检索记忆
results = memory.retrieve("京都旅行", k=2)
print(f"✅ 记忆检索成功")
print(f"   查询: 京都旅行")
print(f"   检索到 {len(results)} 条相关记忆:")
for i, mem in enumerate(results, 1):
    print(f"   {i}. {mem.content[:50]}... (重要性: {mem.importance:.2f})")

# 3. 测试 Tools
print(f"\n[3/3] 测试 Tools 模块")
print("-" * 60)
tools = ToolManager(workspace)

# 测试 3 个工具
test_tasks = [
    ("搜索京都机票价格", "web_search"),
    ("计算 1800 + 1200 + 500", "calculator"),
    ("生成旅行计划报告 travel_plan_test.txt", "file_writer")
]

for task_desc, expected_tool in test_tasks:
    tool = tools.select(task_desc)
    print(f"\n   任务: {task_desc}")
    print(f"   选择工具: {tool.name if tool else 'None'}")
    
    if tool and tool.name == expected_tool:
        print(f"   ✅ 工具选择正确")
        
        # 执行工具
        if tool.name == "web_search":
            result = tools.execute(tool.name, query=task_desc)
        elif tool.name == "calculator":
            result = tools.execute(tool.name, expression="1800 + 1200 + 500")
        elif tool.name == "file_writer":
            result = tools.execute(tool.name, 
                                  file_path="travel_plan_test.txt",
                                  content="测试旅行计划内容")
        
        if result.success:
            print(f"   ✅ 工具执行成功: {result.output}")
        else:
            print(f"   ❌ 工具执行失败: {result.error}")
    else:
        print(f"   ❌ 工具选择错误（期望: {expected_tool}）")

# 统计
print(f"\n" + "=" * 60)
print("📊 测试统计")
print("=" * 60)

tool_stats = tools.get_tool_stats()
print(f"工具执行次数: {tool_stats['total_executions']}")
print(f"成功率: {tool_stats['total_successes'] / max(tool_stats['total_executions'], 1) * 100:.1f}%")

memory_stats = memory.get_stats()
print(f"记忆总数: {memory_stats['short_term_count'] + memory_stats['long_term_count']}")

print(f"\n✅ 所有测试完成！")
print("=" * 60)
