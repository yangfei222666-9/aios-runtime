"""最简单的测试：Reactor v2.0"""
from reactor_v2 import Reactor, Playbook

print("Test 1: Basic Execution")
reactor = Reactor()

playbook = Playbook(
    id="test",
    name="Test",
    actions=[{"type": "shell", "target": "echo 'Hello'", "risk": "low"}]
)

reactor.register_playbook(playbook)
result = reactor.execute_playbook("test")

print(f"Status: {result['status']}")
print(f"Success: {result['action_results'][0]['success']}")
print(f"Output: {result['action_results'][0]['output']}")

assert result["status"] == "success"
print("PASS")

reactor.shutdown()
