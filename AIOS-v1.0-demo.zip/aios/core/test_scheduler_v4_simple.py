"""
简化测试 Scheduler v4.0 - Planning + Memory + Tools 协同工作
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from scheduler import Scheduler
from planner import SubTask

# 创建 Scheduler（集成 Planning + Memory + Tools）
print("初始化 Scheduler v4.0...")
scheduler = Scheduler(workspace=Path(__file__).parent.parent)

print("\n=== AIOS v1.3 - 三大模块协同测试 ===\n")

# 测试 1：简单任务（不需要拆解）
print("测试 1：简单计算任务")
task1 = "计算 100 + 200 + 300"

# 手动创建 SubTask 测试工具执行器
subtask1 = SubTask(
    id="test-1",
    description=task1,
    type="code",
    priority="normal",
    dependencies=[],
    estimated_time=5
)

result1 = scheduler._default_tool_executor(subtask1)
print(f"任务: {task1}")
print(f"结果: {result1.output if result1 else 'None'}")
print(f"观察: {result1.observation if result1 else 'None'}\n")

# 测试 2：文件操作
print("测试 2：文件写入任务")
task2 = "生成一个 test_report.txt 文件"

subtask2 = SubTask(
    id="test-2",
    description=task2,
    type="code",
    priority="normal",
    dependencies=[],
    estimated_time=5
)

result2 = scheduler._default_tool_executor(subtask2, context="这是测试报告内容")
print(f"任务: {task2}")
print(f"结果: {result2.output if result2 else 'None'}")
print(f"观察: {result2.observation if result2 else 'None'}\n")

# 测试 3：搜索任务
print("测试 3：搜索任务")
task3 = "搜索 AIOS 相关信息"

subtask3 = SubTask(
    id="test-3",
    description=task3,
    type="research",
    priority="normal",
    dependencies=[],
    estimated_time=10
)

result3 = scheduler._default_tool_executor(subtask3)
print(f"任务: {task3}")
print(f"结果: {result3.output if result3 else 'None'}")
print(f"观察: {result3.observation if result3 else 'None'}\n")

# 工具使用统计
print("=== 工具使用统计 ===")
tool_stats = scheduler.tools.get_tool_stats()
print(f"总执行次数: {tool_stats['total_executions']}")
print(f"成功率: {tool_stats['total_successes'] / max(tool_stats['total_executions'], 1) * 100:.1f}%")

print("\n各工具统计:")
for tool_stat in tool_stats['tools']:
    if tool_stat['usage_count'] > 0:
        print(f"  {tool_stat['name']}: "
              f"{tool_stat['usage_count']} 次, "
              f"成功率 {tool_stat['success_rate']:.1%}")

print("\n✅ 测试完成！")
