"""
测试 Tools 模块
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from tools import ToolManager

# 创建工具管理器
manager = ToolManager()

print("=== 测试场景 1：旅行规划 ===\n")

# 任务 1：搜索机票价格
task1 = "搜索北京到京都的机票价格"
tool1 = manager.select(task1)
print(f"任务: {task1}")
print(f"选择工具: {tool1.name if tool1 else '无'}")
if tool1:
    result1 = manager.execute(tool1.name, query="北京到京都机票")
    print(f"结果: {result1.output}\n")

# 任务 2：计算预算
task2 = "计算机票1800 + 酒店1200 + 景点500的总预算"
tool2 = manager.select(task2)
print(f"任务: {task2}")
print(f"选择工具: {tool2.name if tool2 else '无'}")
if tool2:
    result2 = manager.execute(tool2.name, expression="1800 + 1200 + 500")
    print(f"结果: {result2.output}元\n")

# 任务 3：生成报告
task3 = "生成旅行计划报告"
tool3 = manager.select(task3)
print(f"任务: {task3}")
print(f"选择工具: {tool3.name if tool3 else '无'}")
if tool3:
    report = f"""
旅行计划报告
============

目的地：京都
预算：3500元

行程安排：
- 第1天：清水寺
- 第2天：金阁寺

总预算：{result2.output}元
"""
    result3 = manager.execute(tool3.name, 
                             file_path="travel_plan.txt", 
                             content=report)
    print(f"结果: {result3.output}\n")

print("\n=== 工具使用统计 ===")
stats = manager.get_tool_stats()
print(f"总执行次数: {stats['total_executions']}")
print(f"成功率: {stats['total_successes'] / stats['total_executions'] * 100:.1f}%")
