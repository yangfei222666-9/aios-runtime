"""
AIOS Queue System - Comprehensive Tests

Tests all four components:
1. LLMQueue (FIFO + Priority)
2. MemoryQueue (SJF / RR / EDF)
3. StorageQueue (SJF / RR + Batch)
4. ThreadPoolManager (Thread binding)
"""
import sys
import threading
import time
from pathlib import Path

AIOS_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(AIOS_ROOT))

from core.queues.base import QueueRequest, RequestPriority, SchedulingPolicy
from core.queues.llm_queue import LLMQueue
from core.queues.memory_queue import MemoryQueue
from core.queues.storage_queue import StorageQueue
from core.queues.thread_pool import ThreadPoolManager, ThreadPool


passed = 0
failed = 0


def test(name: str, condition: bool):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed += 1
        print(f"  FAIL  {name}")


# =====================================================================
# 1. LLM Queue Tests
# =====================================================================
print("\n" + "=" * 60)
print("1. LLM Queue (FIFO + Priority)")
print("=" * 60)

# 1.1 Basic FIFO
q = LLMQueue(max_concurrency=4)
r1 = QueueRequest(name="req1", priority=RequestPriority.NORMAL)
r2 = QueueRequest(name="req2", priority=RequestPriority.NORMAL)
r3 = QueueRequest(name="req3", priority=RequestPriority.NORMAL)
# Ensure ordering by created_at
r1.created_at = 100.0
r2.created_at = 101.0
r3.created_at = 102.0
q.enqueue(r1)
q.enqueue(r2)
q.enqueue(r3)
out = q.dequeue()
test("FIFO: first in first out", out is not None and out.name == "req1")
out = q.dequeue()
test("FIFO: second", out is not None and out.name == "req2")

# 1.2 Priority preemption
q2 = LLMQueue(max_concurrency=4)
low = QueueRequest(name="low", priority=RequestPriority.LOW)
low.created_at = 100.0
high = QueueRequest(name="high", priority=RequestPriority.HIGH)
high.created_at = 101.0
crit = QueueRequest(name="critical", priority=RequestPriority.CRITICAL)
crit.created_at = 102.0
q2.enqueue(low)
q2.enqueue(high)
q2.enqueue(crit)
out = q2.dequeue()
test("Priority: CRITICAL first", out is not None and out.name == "critical")
out = q2.dequeue()
test("Priority: HIGH second", out is not None and out.name == "high")
out = q2.dequeue()
test("Priority: LOW last", out is not None and out.name == "low")

# 1.3 Complete + stats
q3 = LLMQueue(max_concurrency=4)
r = QueueRequest(name="token_test")
q3.enqueue(r)
out = q3.dequeue()
q3.complete(out.id, result="ok", tokens_used=500)
stats = q3.stats()
test("Stats: total_tokens tracked", stats["total_tokens"] == 500)
test("Stats: total_completed", stats["total_completed"] == 1)

# 1.4 Rate limiting
q4 = LLMQueue(max_concurrency=4, rate_limit_rps=2.0)
r_a = QueueRequest(name="a")
r_b = QueueRequest(name="b")
q4.enqueue(r_a)
q4.enqueue(r_b)
out1 = q4.dequeue()
out2 = q4.dequeue()  # should be None (rate limited)
test("Rate limit: second dequeue blocked", out1 is not None and out2 is None)

# 1.5 Empty queue
q5 = LLMQueue()
test("Empty queue returns None", q5.dequeue() is None)

# 1.6 Cancel
q6 = LLMQueue()
r = QueueRequest(name="cancel_me")
q6.enqueue(r)
ok = q6.cancel(r.id)
test("Cancel: returns True", ok is True)
test("Cancel: queue empty after", q6.pending_count() == 0)


# =====================================================================
# 2. Memory Queue Tests
# =====================================================================
print("\n" + "=" * 60)
print("2. Memory Queue (SJF / RR / EDF)")
print("=" * 60)

# 2.1 SJF
mq = MemoryQueue(policy=SchedulingPolicy.SJF)
big = QueueRequest(name="big", estimated_cost=100.0)
small = QueueRequest(name="small", estimated_cost=1.0)
medium = QueueRequest(name="medium", estimated_cost=50.0)
mq.enqueue(big)
mq.enqueue(small)
mq.enqueue(medium)
out = mq.dequeue()
test("SJF: smallest cost first", out is not None and out.name == "small")
out = mq.dequeue()
test("SJF: medium second", out is not None and out.name == "medium")

# 2.2 RR fairness
mq2 = MemoryQueue(policy=SchedulingPolicy.RR, enable_aging=False)
a1 = QueueRequest(name="agent_a_1", agent_id="A", estimated_cost=1.0)
a2 = QueueRequest(name="agent_a_2", agent_id="A", estimated_cost=1.0)
b1 = QueueRequest(name="agent_b_1", agent_id="B", estimated_cost=1.0)
a1.created_at = 100.0
a2.created_at = 101.0
b1.created_at = 102.0
mq2.enqueue(a1)
mq2.enqueue(a2)
mq2.enqueue(b1)
first = mq2.dequeue()
second = mq2.dequeue()
# RR should alternate between agents
agents_served = [first.agent_id, second.agent_id]
test("RR: serves different agents", "A" in agents_served and "B" in agents_served)

# 2.3 EDF
mq3 = MemoryQueue(policy=SchedulingPolicy.EDF, enable_aging=False)
now = time.monotonic()
late = QueueRequest(name="late", deadline=now + 100)
urgent = QueueRequest(name="urgent", deadline=now + 1)
no_dl = QueueRequest(name="no_deadline")
mq3.enqueue(late)
mq3.enqueue(urgent)
mq3.enqueue(no_dl)
out = mq3.dequeue()
test("EDF: nearest deadline first", out is not None and out.name == "urgent")
out = mq3.dequeue()
test("EDF: later deadline second", out is not None and out.name == "late")
out = mq3.dequeue()
test("EDF: no deadline last", out is not None and out.name == "no_deadline")

# 2.4 Policy switch
mq4 = MemoryQueue(policy=SchedulingPolicy.SJF)
test("Policy: starts as SJF", mq4.policy == SchedulingPolicy.SJF)
mq4.set_policy(SchedulingPolicy.RR)
test("Policy: switched to RR", mq4.policy == SchedulingPolicy.RR)

# 2.5 Invalid policy
try:
    mq4.set_policy(SchedulingPolicy.FIFO)
    test("Policy: rejects FIFO", False)
except ValueError:
    test("Policy: rejects FIFO", True)

# 2.6 Aging
mq5 = MemoryQueue(policy=SchedulingPolicy.SJF, enable_aging=True)
old_req = QueueRequest(name="old", priority=RequestPriority.LOW, estimated_cost=100.0)
old_req.created_at = time.monotonic() - 30  # 30 seconds old
new_req = QueueRequest(name="new", priority=RequestPriority.NORMAL, estimated_cost=1.0)
mq5.enqueue(old_req)
mq5.enqueue(new_req)
out = mq5.dequeue()
# After aging, old_req should have boosted priority
# But SJF still picks by cost, so new_req (cost=1) wins unless aging boosts to CRITICAL
# Aging boosts: 30s / 10s = 3 levels, LOW(3) - 3 = 0 (CRITICAL)
# With CRITICAL priority and SJF... SJF doesn't use priority, it uses cost
# So new_req still wins on cost. Aging is more relevant for priority-based policies.
test("Aging: old request priority boosted", old_req.priority == RequestPriority.CRITICAL)


# =====================================================================
# 3. Storage Queue Tests
# =====================================================================
print("\n" + "=" * 60)
print("3. Storage Queue (SJF / RR + Batch)")
print("=" * 60)

# 3.1 Reads before writes
sq = StorageQueue(policy=SchedulingPolicy.SJF, reads_first=True)
w1 = QueueRequest(name="write1", payload={"op": "write", "path": "/data"}, estimated_cost=10.0)
r1 = QueueRequest(name="read1", payload={"op": "read", "path": "/data"}, estimated_cost=50.0)
sq.enqueue(w1)
sq.enqueue(r1)
out = sq.dequeue()
test("Reads first: read before write", out is not None and out.name == "read1")

# 3.2 SJF within same type
sq2 = StorageQueue(policy=SchedulingPolicy.SJF, reads_first=False)
big_w = QueueRequest(name="big_write", payload={"op": "write"}, estimated_cost=100.0)
small_w = QueueRequest(name="small_write", payload={"op": "write"}, estimated_cost=1.0)
sq2.enqueue(big_w)
sq2.enqueue(small_w)
out = sq2.dequeue()
test("SJF: smallest cost first", out is not None and out.name == "small_write")

# 3.3 Batch coalescing
sq3 = StorageQueue(batch_window_sec=0.0)  # immediate batching
for i in range(5):
    r = QueueRequest(
        name=f"batch_{i}",
        payload={"op": "write", "path": "/logs"},
        estimated_cost=1.0,
    )
    r.created_at = time.monotonic() - 1.0  # old enough
    sq3.enqueue(r)
batch = sq3.try_batch()
test("Batch: coalesces same-path requests", batch is not None and len(batch) >= 2)
if batch:
    test("Batch: all same path", all(r.payload["path"] == "/logs" for r in batch))

# 3.4 No batch for different paths
sq4 = StorageQueue(batch_window_sec=0.0)
r_a = QueueRequest(name="a", payload={"op": "write", "path": "/a"})
r_a.created_at = time.monotonic() - 1.0
r_b = QueueRequest(name="b", payload={"op": "write", "path": "/b"})
r_b.created_at = time.monotonic() - 1.0
sq4.enqueue(r_a)
sq4.enqueue(r_b)
batch = sq4.try_batch()
test("Batch: no batch for different paths", batch is None)

# 3.5 Policy switch
sq5 = StorageQueue(policy=SchedulingPolicy.SJF)
sq5.set_policy(SchedulingPolicy.RR)
test("Policy: switched to RR", sq5.policy == SchedulingPolicy.RR)

# 3.6 Stats
sq6 = StorageQueue()
r = QueueRequest(name="stat_test", payload={"op": "read"})
sq6.enqueue(r)
out = sq6.dequeue()
sq6.complete(out.id)
stats = sq6.stats()
test("Stats: completed count", stats["total_completed"] == 1)
test("Stats: reads_first in stats", "reads_first" in stats)


# =====================================================================
# 4. Thread Pool Tests
# =====================================================================
print("\n" + "=" * 60)
print("4. ThreadPoolManager (Thread Binding)")
print("=" * 60)

# 4.1 Create and start pools
mgr = ThreadPoolManager()
mgr.create_pool("llm", size=2)
mgr.create_pool("memory", size=2)
mgr.create_pool("storage", size=1)
test("Create: 3 pools", len(mgr.pool_names) == 3)

mgr.start_all()
time.sleep(0.1)  # let workers spin up

# 4.2 Submit tasks
results = []
lock = threading.Lock()

def make_task(val):
    def task():
        with lock:
            results.append(val)
    return task

pool = mgr.get_pool("llm")
for i in range(5):
    pool.submit(make_task(i))

time.sleep(0.5)
test("Submit: all tasks completed", len(results) == 5)
test("Submit: correct values", sorted(results) == [0, 1, 2, 3, 4])

# 4.3 Resize
pool.resize(4)
test("Resize: pool size updated", pool.size == 4)

# 4.4 Stats
stats = mgr.stats()
test("Stats: has llm pool", "llm" in stats)
test("Stats: has workers", len(stats["llm"]["workers"]) == 4)

# 4.5 Duplicate pool name
try:
    mgr.create_pool("llm", size=1)
    test("Duplicate: raises error", False)
except ValueError:
    test("Duplicate: raises error", True)

# 4.6 Stop
mgr.stop_all()
time.sleep(0.2)
test("Stop: pools stopped", True)


# =====================================================================
# 5. Integration: Queue + ThreadPool
# =====================================================================
print("\n" + "=" * 60)
print("5. Integration (Queue + ThreadPool)")
print("=" * 60)

mgr2 = ThreadPoolManager()
mgr2.create_pool("llm", size=2)
mgr2.start_all()

llm_q = LLMQueue(max_concurrency=4)
integration_results = []
int_lock = threading.Lock()

# Enqueue requests
for i in range(3):
    r = QueueRequest(name=f"llm_req_{i}", priority=RequestPriority.NORMAL)
    llm_q.enqueue(r)

# Process via thread pool
llm_pool = mgr2.get_pool("llm")

def process_queue():
    req = llm_q.dequeue()
    if req:
        # Simulate LLM call
        time.sleep(0.05)
        llm_q.complete(req.id, result=f"response_{req.name}", tokens_used=100)
        with int_lock:
            integration_results.append(req.name)

for _ in range(3):
    llm_pool.submit(process_queue)

time.sleep(1.0)
test("Integration: all requests processed", len(integration_results) == 3)
test("Integration: queue stats correct", llm_q.stats()["total_completed"] == 3)
test("Integration: tokens tracked", llm_q.stats()["total_tokens"] == 300)

mgr2.stop_all()


# =====================================================================
# Summary
# =====================================================================
print("\n" + "=" * 60)
total = passed + failed
print(f"Results: {passed}/{total} PASS, {failed}/{total} FAIL")
if failed == 0:
    print("ALL TESTS PASSED!")
else:
    print(f"WARNING: {failed} test(s) failed")
print("=" * 60)

sys.exit(0 if failed == 0 else 1)
