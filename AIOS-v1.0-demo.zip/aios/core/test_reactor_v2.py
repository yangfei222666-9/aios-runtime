"""
单元测试：Reactor v2.0
覆盖：并发安全、熔断器恢复、超时保护、快速失败
"""
import unittest
import time
import threading
from reactor_v2 import Reactor, Playbook, CircuitState


class TestReactor(unittest.TestCase):
    
    def setUp(self):
        """每个测试前初始化"""
        self.reactor = Reactor(max_workers=3, action_timeout=2)
    
    def tearDown(self):
        """每个测试后清理"""
        try:
            self.reactor.shutdown(wait=False)
        except:
            pass
    
    def test_basic_execution(self):
        """测试基本执行"""
        playbook = Playbook(
            id="test_basic",
            name="Basic Test",
            actions=[
                {"type": "shell", "target": "echo 'test'", "risk": "low"},
            ]
        )
        
        self.reactor.register_playbook(playbook)
        result = self.reactor.execute_playbook("test_basic")
        
        self.assertEqual(result["status"], "success")
        self.assertEqual(len(result["action_results"]), 1)
        self.assertTrue(result["action_results"][0]["success"])
    
    def test_concurrent_safety(self):
        """测试并发安全（50线程同时执行）"""
        playbook = Playbook(
            id="test_concurrent",
            name="Concurrent Test",
            actions=[
                {"type": "shell", "target": "echo 'concurrent'", "risk": "low"},
            ]
        )
        
        self.reactor.register_playbook(playbook)
        
        results = []
        errors = []
        
        def execute():
            try:
                result = self.reactor.execute_playbook("test_concurrent")
                results.append(result)
            except Exception as e:
                errors.append(e)
        
        # 50个线程同时执行
        threads = [threading.Thread(target=execute) for _ in range(50)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # 验证：无异常，所有执行成功
        self.assertEqual(len(errors), 0, f"Concurrent errors: {errors}")
        self.assertEqual(len(results), 50)
        self.assertTrue(all(r["status"] == "success" for r in results))
    
    def test_circuit_breaker_open(self):
        """测试熔断器触发"""
        playbook = Playbook(
            id="test_cb_open",
            name="Circuit Breaker Test",
            actions=[
                {"type": "shell", "target": "exit 1", "risk": "low"},  # 总是失败
            ]
        )
        
        self.reactor.register_playbook(playbook)
        
        # 连续失败3次，触发熔断
        for i in range(3):
            result = self.reactor.execute_playbook("test_cb_open")
            self.assertEqual(result["status"], "partial_failure")
        
        # 第4次应该被熔断器拦截
        result = self.reactor.execute_playbook("test_cb_open")
        self.assertEqual(result["status"], "circuit_open")
        
        # 验证熔断器状态
        cb_status = self.reactor.get_circuit_breaker_status("test_cb_open")
        self.assertEqual(cb_status["state"], CircuitState.OPEN.value)
        self.assertFalse(cb_status["can_execute"])
    
    def test_circuit_breaker_recovery(self):
        """测试熔断器自动恢复（30秒后进入 half-open）"""
        playbook = Playbook(
            id="test_cb_recovery",
            name="Circuit Breaker Recovery Test",
            actions=[
                {"type": "shell", "target": "exit 1", "risk": "low"},
            ]
        )
        
        self.reactor.register_playbook(playbook)
        
        # 触发熔断
        for i in range(3):
            self.reactor.execute_playbook("test_cb_recovery")
        
        # 验证熔断
        cb_status = self.reactor.get_circuit_breaker_status("test_cb_recovery")
        self.assertEqual(cb_status["state"], CircuitState.OPEN.value)
        
        # 修改熔断器超时为1秒（加速测试）
        with self.reactor.lock:
            self.reactor.circuit_breakers["test_cb_recovery"].timeout_seconds = 1
        
        # 等待1秒
        time.sleep(1.1)
        
        # 验证进入 half-open
        cb_status = self.reactor.get_circuit_breaker_status("test_cb_recovery")
        self.assertEqual(cb_status["state"], CircuitState.HALF_OPEN.value)
        self.assertTrue(cb_status["can_execute"])
    
    def test_timeout_protection(self):
        """测试超时保护"""
        playbook = Playbook(
            id="test_timeout",
            name="Timeout Test",
            actions=[
                {"type": "shell", "target": "Start-Sleep -Seconds 10", "risk": "low"},  # 睡眠10秒
            ]
        )
        
        self.reactor.register_playbook(playbook)
        
        start = time.time()
        result = self.reactor.execute_playbook("test_timeout")
        elapsed = time.time() - start
        
        # 应该在2秒左右超时（action_timeout=2）
        self.assertLess(elapsed, 5, "Timeout should trigger within 5 seconds")
        self.assertEqual(result["status"], "partial_failure")
        self.assertIn("TIMEOUT", result["action_results"][0]["output"])
    
    def test_fast_fail(self):
        """测试快速失败（高风险操作失败后跳过后续）"""
        playbook = Playbook(
            id="test_fast_fail",
            name="Fast Fail Test",
            actions=[
                {"type": "shell", "target": "exit 1", "risk": "high"},  # 高风险失败
                {"type": "shell", "target": "echo 'should skip'", "risk": "low"},  # 应该被跳过
            ]
        )
        
        self.reactor.register_playbook(playbook)
        result = self.reactor.execute_playbook("test_fast_fail")
        
        self.assertEqual(result["status"], "partial_failure")
        self.assertEqual(len(result["action_results"]), 2)
        self.assertFalse(result["action_results"][0]["success"])
        self.assertIn("SKIPPED", result["action_results"][1]["output"])
    
    def test_dry_run(self):
        """测试演练模式"""
        playbook = Playbook(
            id="test_dry_run",
            name="Dry Run Test",
            actions=[
                {"type": "shell", "target": "echo 'test'", "risk": "low"},
            ]
        )
        
        self.reactor.register_playbook(playbook)
        result = self.reactor.execute_playbook("test_dry_run", dry_run=True)
        
        self.assertEqual(result["status"], "success")
        self.assertTrue(result["dry_run"])
        self.assertIn("DRY_RUN", result["action_results"][0]["output"])
    
    def test_stats(self):
        """测试统计追踪"""
        playbook = Playbook(
            id="test_stats",
            name="Stats Test",
            actions=[
                {"type": "shell", "target": "echo 'test'", "risk": "low"},
            ]
        )
        
        self.reactor.register_playbook(playbook)
        
        # 执行5次
        for i in range(5):
            self.reactor.execute_playbook("test_stats")
        
        stats = self.reactor.get_stats()
        self.assertEqual(stats["total_executed"], 5)
        self.assertEqual(stats["total_success"], 5)
        self.assertEqual(stats["playbooks_registered"], 1)
    
    def test_playbook_validation(self):
        """测试剧本验证"""
        # 无 ID
        with self.assertRaises(ValueError):
            playbook = Playbook(id="", name="Test", actions=[])
            self.reactor.register_playbook(playbook)
        
        # 无 actions
        with self.assertRaises(ValueError):
            playbook = Playbook(id="test", name="Test", actions=[])
            self.reactor.register_playbook(playbook)
        
        # action 缺少 type
        with self.assertRaises(ValueError):
            playbook = Playbook(
                id="test",
                name="Test",
                actions=[{"target": "echo 'test'"}]
            )
            self.reactor.register_playbook(playbook)


if __name__ == "__main__":
    unittest.main(verbosity=2)
