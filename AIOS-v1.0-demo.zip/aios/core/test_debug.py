"""Debug test"""
import time
import logging
from scheduler_v2_1 import Scheduler

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(message)s")

print("Creating scheduler...")
scheduler = Scheduler(max_concurrent=2)

print("Defining task...")
def task():
    print("[Task] Running...")
    time.sleep(0.1)
    print("[Task] Done")
    return "success"

print("Scheduling task...")
task_id = scheduler.schedule({"id": "test", "func": task})
print(f"[Main] Task {task_id} scheduled")

print("[Main] Waiting 2 seconds...")
time.sleep(2.0)

print(f"[Main] Completed: {scheduler.completed}")
print(f"[Main] Running: {scheduler.running}")
print(f"[Main] Queues: {[len(q) for q in scheduler.queues.values()]}")

scheduler.shutdown(wait=False)
print("[Main] Done!")
