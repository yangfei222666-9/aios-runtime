"""
单元测试：Scheduler v2.1
覆盖：依赖、优先级、超时、取消、重试、回调
"""
import unittest
import time
from scheduler_v2_1 import Scheduler, Priority


class TestScheduler(unittest.TestCase):
    
    def setUp(self):
        """每个测试前初始化"""
        self.scheduler = Scheduler(max_concurrent=3, default_timeout=2)
    
    def tearDown(self):
        """每个测试后清理"""
        # 先停止接受新任务，然后等待当前任务完成
        try:
            self.scheduler.shutdown(wait=False)
        except:
            pass
    
    def test_basic_execution(self):
        """测试基本任务执行"""
        result = []
        
        def task():
            result.append("done")
            return "success"
        
        self.scheduler.schedule({"id": "test", "func": task})
        time.sleep(0.5)
        
        self.assertIn("test", self.scheduler.completed)
        self.assertEqual(result, ["done"])
    
    def test_dependency(self):
        """测试依赖关系"""
        order = []
        
        def task_a():
            order.append("A")
            return "A done"
        
        def task_b():
            order.append("B")
            return "B done"
        
        self.scheduler.schedule({"id": "A", "func": task_a})
        self.scheduler.schedule({"id": "B", "func": task_b, "depends_on": ["A"]})
        
        time.sleep(1.0)
        
        self.assertEqual(order, ["A", "B"])
        self.assertIn("A", self.scheduler.completed)
        self.assertIn("B", self.scheduler.completed)
    
    def test_priority(self):
        """测试优先级"""
        order = []
        
        def task(name):
            def fn():
                order.append(name)
                time.sleep(0.1)
                return f"{name} done"
            return fn
        
        # 提交低优先级任务
        self.scheduler.schedule({"id": "low", "func": task("low"), "priority": Priority.P3_LOW.value})
        
        # 稍等一下，让低优先级任务开始执行
        time.sleep(0.05)
        
        # 提交高优先级任务
        self.scheduler.schedule({"id": "high", "func": task("high"), "priority": Priority.P0_CRITICAL.value})
        
        time.sleep(0.5)
        
        # 高优先级应该在低优先级之后执行（因为低优先级已经开始了）
        # 但如果有更多任务，高优先级会优先
        self.assertIn("low", order)
        self.assertIn("high", order)
    
    def test_timeout(self):
        """测试超时"""
        def slow_task():
            time.sleep(5)  # 超过 default_timeout=2
            return "should timeout"
        
        self.scheduler.schedule({"id": "slow", "func": slow_task, "timeout_sec": 1})
        time.sleep(2)
        
        self.assertEqual(self.scheduler.stats["total_timeout"], 1)
        self.assertNotIn("slow", self.scheduler.completed)
    
    def test_cancel_queued(self):
        """测试取消队列中的任务"""
        def task():
            time.sleep(1)
            return "done"
        
        # 填满并发槽位
        for i in range(3):
            self.scheduler.schedule({"id": f"running_{i}", "func": task})
        
        # 提交一个会在队列中的任务
        self.scheduler.schedule({"id": "queued", "func": task})
        
        time.sleep(0.1)
        
        # 取消队列中的任务
        cancelled = self.scheduler.cancel("queued")
        
        self.assertTrue(cancelled)
        self.assertIn("queued", self.scheduler.cancelled_tasks)
        
        time.sleep(2)
        
        self.assertNotIn("queued", self.scheduler.completed)
    
    def test_retry(self):
        """测试重试机制"""
        attempts = []
        
        def failing_task():
            attempts.append(1)
            if len(attempts) < 3:
                raise ValueError("Intentional failure")
            return "success after retries"
        
        self.scheduler.schedule({"id": "retry", "func": failing_task, "max_retries": 3})
        time.sleep(1.5)
        
        # 应该重试3次（初始1次 + 重试2次）
        self.assertEqual(len(attempts), 3)
        self.assertIn("retry", self.scheduler.completed)
    
    def test_callback(self):
        """测试回调钩子"""
        completed_tasks = []
        
        def on_complete(task_id, result):
            completed_tasks.append(task_id)
        
        self.scheduler.on_task_complete = on_complete
        
        def task():
            return "done"
        
        self.scheduler.schedule({"id": "callback_test", "func": task})
        time.sleep(0.5)
        
        self.assertIn("callback_test", completed_tasks)
    
    def test_progress(self):
        """测试进度追踪"""
        def task():
            time.sleep(0.1)
            return "done"
        
        # 提交5个任务
        for i in range(5):
            self.scheduler.schedule({"id": f"task_{i}", "func": task})
        
        time.sleep(0.05)
        progress = self.scheduler.get_progress()
        
        self.assertEqual(progress["total"], 5)
        self.assertGreater(progress["running"], 0)
        
        time.sleep(1.0)
        progress = self.scheduler.get_progress()
        
        self.assertEqual(progress["completed"], 5)
        self.assertEqual(progress["progress_percent"], 100.0)
    
    def test_concurrent_limit(self):
        """测试并发限制"""
        running_count = []
        
        def task():
            running_count.append(1)
            time.sleep(0.2)
            running_count.pop()
            return "done"
        
        # 提交10个任务
        for i in range(10):
            self.scheduler.schedule({"id": f"task_{i}", "func": task})
        
        time.sleep(0.1)
        
        # 最多3个并发
        self.assertLessEqual(len(running_count), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
