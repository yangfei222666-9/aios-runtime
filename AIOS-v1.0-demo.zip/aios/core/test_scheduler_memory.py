"""
测试 Scheduler + Memory 集成
"""
from pathlib import Path
import time
import sys

sys.path.insert(0, str(Path(__file__).parent))
from scheduler import Scheduler
from planner import SubTask

workspace = Path(__file__).parent.parent.parent
scheduler = Scheduler(max_concurrent=3, default_timeout=10, workspace=workspace)

print("=== Scheduler + Memory 集成测试 ===\n")

# 测试：带记忆检索的任务调度
print("测试：带记忆检索的任务调度")

def executor(subtask: SubTask, context: str = None):
    print(f"  执行: {subtask.description}")
    if context:
        print(f"  上下文: {context[:50]}...")
    time.sleep(0.5)
    return f"{subtask.description} - 完成"

def on_complete(plan):
    print(f"\n🎉 Plan {plan.task_id} 完成！")
    for st in plan.subtasks:
        print(f"  - {st.description}: {st.status}")

# 第一次执行（没有记忆）
print("\n第一次执行（没有记忆）:")
plan_id_1 = scheduler.schedule_with_planning(
    "实现 Tool Use 模块",
    executor=executor,
    callback=on_complete,
    use_memory=True
)
time.sleep(5)

# 第二次执行（有记忆）
print("\n第二次执行（有记忆，应该检索到第一次的经验）:")
plan_id_2 = scheduler.schedule_with_planning(
    "实现 Tool Use 模块的测试",
    executor=executor,
    callback=on_complete,
    use_memory=True
)
time.sleep(5)

# 查看记忆统计
if scheduler.memory:
    stats = scheduler.memory.get_stats()
    print(f"\n记忆统计:")
    print(f"  短期记忆: {stats['short_term_count']}")
    print(f"  长期记忆: {stats['long_term_count']}")
    print(f"  总记忆数: {stats['total_memories']}")

scheduler.shutdown()
print("\n[OK] 测试完成！")
