"""简化测试：Reactor v2.0（避免 unittest 编码问题）"""
import time
from reactor_v2 import Reactor, Playbook, CircuitState

print("=" * 80)
print("Reactor v2.0 - 生产级测试套件")
print("=" * 80)

# Test 1: 基本执行
print("\n=== Test 1: Basic Execution ===")
reactor = Reactor(max_workers=3, action_timeout=5)

playbook = Playbook(
    id="test_basic",
    name="Basic Test",
    actions=[
        {"type": "shell", "target": "echo 'Hello Reactor v2.0'", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)
result = reactor.execute_playbook("test_basic")

assert result["status"] == "success", f"Expected success, got {result['status']}"
assert len(result["action_results"]) == 1
assert result["action_results"][0]["success"]
print("✅ PASS")

reactor.shutdown(wait=False)

# Test 2: 熔断器触发
print("\n=== Test 2: Circuit Breaker Trigger ===")
reactor = Reactor(max_workers=3, action_timeout=5)

playbook = Playbook(
    id="test_cb",
    name="Circuit Breaker Test",
    actions=[
        {"type": "shell", "target": "exit 1", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)

# 连续失败3次
for i in range(3):
    result = reactor.execute_playbook("test_cb")
    print(f"  Attempt {i+1}: {result['status']}")

# 第4次应该被熔断
result = reactor.execute_playbook("test_cb")
print(f"  Attempt 4: {result['status']}")

assert result["status"] == "circuit_open", f"Expected circuit_open, got {result['status']}"

cb_status = reactor.get_circuit_breaker_status("test_cb")
assert cb_status["state"] == CircuitState.OPEN.value
print(f"  Circuit breaker state: {cb_status['state']}")
print("✅ PASS")

reactor.shutdown(wait=False)

# Test 3: 熔断器恢复
print("\n=== Test 3: Circuit Breaker Recovery ===")
reactor = Reactor(max_workers=3, action_timeout=5)

playbook = Playbook(
    id="test_recovery",
    name="Recovery Test",
    actions=[
        {"type": "shell", "target": "exit 1", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)

# 触发熔断
for i in range(3):
    reactor.execute_playbook("test_recovery")

# 修改超时为1秒（加速测试）
with reactor.lock:
    reactor.circuit_breakers["test_recovery"].timeout_seconds = 1

print("  Waiting 1.5 seconds for half-open...")
time.sleep(1.5)

cb_status = reactor.get_circuit_breaker_status("test_recovery")
print(f"  State after 1.5s: {cb_status['state']}")
assert cb_status["state"] == CircuitState.HALF_OPEN.value
print("✅ PASS")

reactor.shutdown(wait=False)

# Test 4: 超时保护
print("\n=== Test 4: Timeout Protection ===")
reactor = Reactor(max_workers=3, action_timeout=2)

playbook = Playbook(
    id="test_timeout",
    name="Timeout Test",
    actions=[
        {"type": "shell", "target": "Start-Sleep -Seconds 5", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)

start = time.time()
result = reactor.execute_playbook("test_timeout")
elapsed = time.time() - start

print(f"  Elapsed: {elapsed:.2f}s")
print(f"  Status: {result['status']}")
print(f"  Output: {result['action_results'][0]['output']}")

assert elapsed < 5, f"Timeout should trigger within 5s, got {elapsed:.2f}s"
assert result["status"] == "partial_failure"
assert "TIMEOUT" in result["action_results"][0]["output"]
print("✅ PASS")

reactor.shutdown(wait=False)

# Test 5: 快速失败
print("\n=== Test 5: Fast Fail ===")
reactor = Reactor(max_workers=3, action_timeout=5)

playbook = Playbook(
    id="test_fast_fail",
    name="Fast Fail Test",
    actions=[
        {"type": "shell", "target": "exit 1", "risk": "high"},
        {"type": "shell", "target": "echo 'should skip'", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)
result = reactor.execute_playbook("test_fast_fail")

print(f"  Status: {result['status']}")
print(f"  Action 1: {result['action_results'][0]['output']}")
print(f"  Action 2: {result['action_results'][1]['output']}")

assert result["status"] == "partial_failure"
assert len(result["action_results"]) == 2
assert not result["action_results"][0]["success"]
assert "SKIPPED" in result["action_results"][1]["output"]
print("✅ PASS")

reactor.shutdown(wait=False)

# Test 6: 统计追踪
print("\n=== Test 6: Stats Tracking ===")
reactor = Reactor(max_workers=3, action_timeout=5)

playbook = Playbook(
    id="test_stats",
    name="Stats Test",
    actions=[
        {"type": "shell", "target": "echo 'test'", "risk": "low"},
    ]
)

reactor.register_playbook(playbook)

for i in range(5):
    reactor.execute_playbook("test_stats")

stats = reactor.get_stats()
print(f"  Total executed: {stats['total_executed']}")
print(f"  Total success: {stats['total_success']}")
print(f"  Playbooks registered: {stats['playbooks_registered']}")

assert stats["total_executed"] == 5
assert stats["total_success"] == 5
print("✅ PASS")

reactor.shutdown(wait=False)

print("\n" + "=" * 80)
print("🎉 All tests passed! Reactor v2.0 is production-ready!")
print("=" * 80)
