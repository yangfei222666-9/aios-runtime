"""简化测试：Scheduler v2.1"""
import time
from scheduler_v2_1 import Scheduler, Priority

print("=== Test 1: Basic Execution ===")
scheduler = Scheduler(max_concurrent=2)

result = []
def task():
    result.append("done")
    return "success"

task_id = scheduler.schedule({"id": "test1", "func": task})
time.sleep(0.5)

assert "test1" in scheduler.completed, "Task should be completed"
assert result == ["done"], "Task should have executed"
print("✅ PASS\n")

scheduler.shutdown(wait=False)

print("=== Test 2: Dependency ===")
scheduler = Scheduler(max_concurrent=2)

order = []
def task_a():
    order.append("A")
    return "A done"

def task_b():
    order.append("B")
    return "B done"

scheduler.schedule({"id": "A", "func": task_a})
scheduler.schedule({"id": "B", "func": task_b, "depends_on": ["A"]})
time.sleep(1.0)

assert order == ["A", "B"], f"Order should be ['A', 'B'], got {order}"
print("✅ PASS\n")

scheduler.shutdown(wait=False)

print("=== Test 3: Priority ===")
scheduler = Scheduler(max_concurrent=1)  # 只允许1个并发

order = []
def task(name):
    def fn():
        order.append(name)
        time.sleep(0.2)
        return f"{name} done"
    return fn

# 提交低优先级任务
scheduler.schedule({"id": "low", "func": task("low"), "priority": Priority.P3_LOW.value})
time.sleep(0.05)  # 让低优先级任务开始

# 提交高优先级任务
scheduler.schedule({"id": "high", "func": task("high"), "priority": Priority.P0_CRITICAL.value})

# 提交中优先级任务
scheduler.schedule({"id": "mid", "func": task("mid"), "priority": Priority.P2_MEDIUM.value})

time.sleep(1.5)

# low 先开始，然后 high（高优先级），最后 mid
assert order[0] == "low", f"First should be 'low', got {order[0]}"
assert order[1] == "high", f"Second should be 'high' (priority), got {order[1]}"
assert order[2] == "mid", f"Third should be 'mid', got {order[2]}"
print(f"Order: {order}")
print("✅ PASS\n")

scheduler.shutdown(wait=False)

print("=== Test 4: Cancel ===")
scheduler = Scheduler(max_concurrent=1)

def slow_task():
    time.sleep(1)
    return "done"

# 提交2个任务（第2个会在队列中）
scheduler.schedule({"id": "running", "func": slow_task})
scheduler.schedule({"id": "queued", "func": slow_task})

time.sleep(0.1)

# 取消队列中的任务
cancelled = scheduler.cancel("queued")
assert cancelled, "Should be able to cancel queued task"

time.sleep(1.5)

assert "queued" not in scheduler.completed, "Cancelled task should not complete"
assert "queued" in scheduler.cancelled_tasks, "Task should be in cancelled set"
print("✅ PASS\n")

scheduler.shutdown(wait=False)

print("=== Test 5: Stats ===")
scheduler = Scheduler(max_concurrent=2)

def task():
    time.sleep(0.1)
    return "done"

for i in range(5):
    scheduler.schedule({"id": f"task_{i}", "func": task})

time.sleep(1.0)

stats = scheduler.get_stats()
assert stats["total_submitted"] == 5, f"Should have 5 submitted, got {stats['total_submitted']}"
assert stats["total_completed"] == 5, f"Should have 5 completed, got {stats['total_completed']}"
print(f"Stats: {stats}")
print("✅ PASS\n")

scheduler.shutdown(wait=False)

print("=" * 50)
print("🎉 All tests passed!")
