"""
Scheduler v5.0 测试 - VM 集成
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from scheduler_v5 import Scheduler
import time


def test_basic_vm_execution():
    """测试基础 VM 执行"""
    print("\n=== 测试1：基础 VM 执行 ===\n")
    
    scheduler = Scheduler(max_concurrent=3, use_vm=True, vm_pool_size=2)
    
    try:
        # 创建 3 个简单任务
        tasks = [
            {
                'id': 'task-1',
                'func': 'python3 -c "print(\'Task 1: Hello from VM\')"'
            },
            {
                'id': 'task-2',
                'func': 'python3 -c "print(\'Task 2: 1+1=\", 1+1)"'
            },
            {
                'id': 'task-3',
                'func': 'python3 -c "import time; time.sleep(0.1); print(\'Task 3: Done\')"'
            }
        ]
        
        # 调度任务
        for task in tasks:
            scheduler.schedule(task)
        
        # 运行调度器
        start_time = time.time()
        scheduler.run()
        elapsed = time.time() - start_time
        
        # 验证结果
        print(f"\n✅ 所有任务完成")
        print(f"   总耗时: {elapsed:.2f}秒")
        print(f"   统计: {scheduler.stats}")
        print()
    
    finally:
        scheduler.shutdown()


def test_parallel_vm_execution():
    """测试并行 VM 执行"""
    print("\n=== 测试2：并行 VM 执行 ===\n")
    
    scheduler = Scheduler(max_concurrent=3, use_vm=True, vm_pool_size=3)
    
    try:
        # 创建 3 个计算密集型任务
        tasks = [
            {
                'id': 'compute-1',
                'func': 'python3 -c "result = sum(i*i for i in range(1000000)); print(f\'Result: {result}\')"'
            },
            {
                'id': 'compute-2',
                'func': 'python3 -c "result = sum(i**3 for i in range(100000)); print(f\'Result: {result}\')"'
            },
            {
                'id': 'compute-3',
                'func': 'python3 -c "result = len([i for i in range(100000) if i % 2 == 0]); print(f\'Result: {result}\')"'
            }
        ]
        
        # 调度任务
        for task in tasks:
            scheduler.schedule(task)
        
        # 运行调度器
        print("开始并行执行...")
        start_time = time.time()
        scheduler.run()
        elapsed = time.time() - start_time
        
        # 验证结果
        print(f"\n✅ 并行执行完成")
        print(f"   总耗时: {elapsed:.2f}秒")
        print(f"   统计: {scheduler.stats}")
        print(f"   VM 执行: {scheduler.stats['vm_executions']}")
        print(f"   本地执行: {scheduler.stats['local_executions']}")
        print()
    
    finally:
        scheduler.shutdown()


def test_dependency_with_vm():
    """测试依赖关系 + VM 执行"""
    print("\n=== 测试3：依赖关系 + VM 执行 ===\n")
    
    scheduler = Scheduler(max_concurrent=3, use_vm=True, vm_pool_size=2)
    
    try:
        # 创建有依赖关系的任务
        tasks = [
            {
                'id': 'step-1',
                'func': 'python3 -c "print(\'Step 1: Data preparation\')"'
            },
            {
                'id': 'step-2',
                'func': 'python3 -c "print(\'Step 2: Data processing\')"',
                'depends_on': ['step-1']
            },
            {
                'id': 'step-3',
                'func': 'python3 -c "print(\'Step 3: Data analysis\')"',
                'depends_on': ['step-2']
            },
            {
                'id': 'step-4',
                'func': 'python3 -c "print(\'Step 4: Report generation\')"',
                'depends_on': ['step-3']
            }
        ]
        
        # 调度任务
        for task in tasks:
            scheduler.schedule(task)
        
        # 运行调度器
        print("开始执行（按依赖顺序）...")
        start_time = time.time()
        scheduler.run()
        elapsed = time.time() - start_time
        
        # 验证结果
        print(f"\n✅ 依赖任务执行完成")
        print(f"   总耗时: {elapsed:.2f}秒")
        print(f"   统计: {scheduler.stats}")
        print()
    
    finally:
        scheduler.shutdown()


def test_vm_vs_local():
    """测试 VM 执行 vs 本地执行性能对比"""
    print("\n=== 测试4：VM vs 本地执行性能对比 ===\n")
    
    # 本地执行
    print("1. 本地执行...")
    scheduler_local = Scheduler(max_concurrent=3, use_vm=False)
    
    def local_task():
        return sum(i*i for i in range(100000))
    
    tasks_local = [
        {'id': f'local-{i}', 'func': local_task}
        for i in range(3)
    ]
    
    for task in tasks_local:
        scheduler_local.schedule(task)
    
    start_local = time.time()
    scheduler_local.run()
    time_local = time.time() - start_local
    scheduler_local.shutdown()
    
    print(f"   本地执行耗时: {time_local:.2f}秒\n")
    
    # VM 执行
    print("2. VM 执行...")
    scheduler_vm = Scheduler(max_concurrent=3, use_vm=True, vm_pool_size=3)
    
    tasks_vm = [
        {
            'id': f'vm-{i}',
            'func': 'python3 -c "result = sum(i*i for i in range(100000)); print(result)"'
        }
        for i in range(3)
    ]
    
    for task in tasks_vm:
        scheduler_vm.schedule(task)
    
    start_vm = time.time()
    scheduler_vm.run()
    time_vm = time.time() - start_vm
    scheduler_vm.shutdown()
    
    print(f"   VM 执行耗时: {time_vm:.2f}秒\n")
    
    # 对比
    print("3. 性能对比...")
    print(f"   本地执行: {time_local:.2f}秒")
    print(f"   VM 执行: {time_vm:.2f}秒")
    print(f"   开销: {(time_vm - time_local):.2f}秒 ({(time_vm/time_local - 1)*100:.1f}%)")
    print()


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Scheduler v5.0 - VM 集成测试")
    print("="*60)
    
    # 运行所有测试
    test_basic_vm_execution()
    test_parallel_vm_execution()
    test_dependency_with_vm()
    test_vm_vs_local()
    
    print("\n" + "="*60)
    print("所有测试完成 ✅")
    print("="*60 + "\n")
