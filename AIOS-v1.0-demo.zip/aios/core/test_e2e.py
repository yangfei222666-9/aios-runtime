"""
AIOS v1.3 完整端到端测试
测试场景：旅行规划（Planning + Memory + Tools 协同工作）
"""
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from scheduler import Scheduler

print("=" * 60)
print("AIOS v1.3 端到端测试")
print("场景：旅行规划（Planning + Memory + Tools 协同工作）")
print("=" * 60)

# 创建 Scheduler（集成 Planning + Memory + Tools）
print("\n[1/5] 初始化 AIOS...")
scheduler = Scheduler(workspace=Path(__file__).parent.parent)
print("✅ Scheduler v4.0 已启动")
print(f"   - Planning: {scheduler.planner is not None}")
print(f"   - Memory: {scheduler.memory is not None}")
print(f"   - Tools: {scheduler.tools is not None}")

# 测试任务
task = "帮我规划一次周末去京都的旅行，包括搜索机票、预订酒店、计算预算"

print(f"\n[2/5] 用户输入任务...")
print(f"📝 任务: {task}")

# 调度任务（自动拆解 + 记忆检索 + 工具执行）
print(f"\n[3/5] AIOS 自动处理...")
print("   → Planning: 拆解任务")
print("   → Memory: 检索相关记忆")
print("   → Tools: 自动选择工具")

plan_id = scheduler.schedule_with_planning(
    task,
    use_memory=True,   # 启用记忆检索
    use_tools=True     # 启用工具自动执行
)

print(f"✅ Plan ID: {plan_id}")

# 等待任务完成
print(f"\n[4/5] 等待任务执行...")
time.sleep(2)

# 获取 Plan 状态
status = scheduler.get_plan_status(plan_id)

print(f"\n[5/5] 执行结果")
print("=" * 60)
print(f"📊 总任务数: {status['total']}")
print(f"✅ 已完成: {status['completed']}")
print(f"🔄 进行中: {status['running']}")
print(f"⏳ 待执行: {status['pending']}")
print(f"❌ 失败: {status['failed']}")

print(f"\n📋 子任务详情:")
for i, subtask in enumerate(status['subtasks'], 1):
    status_emoji = {
        'completed': '✅',
        'running': '🔄',
        'pending': '⏳',
        'failed': '❌'
    }.get(subtask['status'], '❓')
    
    print(f"\n{i}. {status_emoji} {subtask['description']}")
    print(f"   类型: {subtask['type']}")
    print(f"   优先级: {subtask['priority']}")
    if subtask.get('result'):
        result_str = str(subtask['result'])
        if len(result_str) > 100:
            result_str = result_str[:100] + "..."
        print(f"   结果: {result_str}")

# 工具使用统计
print(f"\n🔧 工具使用统计:")
print("=" * 60)
tool_stats = scheduler.tools.get_tool_stats()
print(f"总执行次数: {tool_stats['total_executions']}")
if tool_stats['total_executions'] > 0:
    success_rate = tool_stats['total_successes'] / tool_stats['total_executions'] * 100
    print(f"成功率: {success_rate:.1f}%")
    
    print(f"\n各工具统计:")
    for tool_stat in tool_stats['tools']:
        if tool_stat['usage_count'] > 0:
            print(f"  • {tool_stat['name']}: "
                  f"{tool_stat['usage_count']} 次, "
                  f"成功率 {tool_stat['success_rate']:.1%}, "
                  f"平均耗时 {tool_stat['avg_time']:.3f}s")

# 记忆统计
print(f"\n🧠 记忆统计:")
print("=" * 60)
memory_stats = scheduler.memory.get_stats()
print(f"短期记忆: {memory_stats['short_term_count']} 条")
print(f"长期记忆: {memory_stats['long_term_count']} 条")
print(f"工作记忆: {memory_stats['working_memory_count']} 条")

print("\n" + "=" * 60)
print("✅ 测试完成！")
print("=" * 60)

# 关闭 Scheduler
scheduler.shutdown()
print("\n🔒 Scheduler 已关闭")
