"""测试 Scheduler v2.1 的取消功能"""
import logging
import time
from scheduler_v2_1 import Scheduler, Priority

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

scheduler = Scheduler(max_concurrent=2, default_timeout=5)  # 只允许2个并发

def slow_task(name):
    def task():
        print(f"[{name}] Starting...")
        time.sleep(1.0)
        print(f"[{name}] Done")
        return f"{name} completed"
    return task

# 提交4个任务（max_concurrent=2，所以后2个会在队列中）
scheduler.schedule({"id": "A", "func": slow_task("A"), "priority": Priority.P3_LOW.value})
scheduler.schedule({"id": "B", "func": slow_task("B"), "priority": Priority.P3_LOW.value})
scheduler.schedule({"id": "C", "func": slow_task("C"), "priority": Priority.P3_LOW.value})
scheduler.schedule({"id": "D", "func": slow_task("D"), "priority": Priority.P3_LOW.value})

# 等待一下，让 A 和 B 开始执行
time.sleep(0.2)

# 现在 C 和 D 应该在队列中，尝试取消 D
print("\n=== Attempting to cancel D ===")
cancelled = scheduler.cancel("D")
print(f"Cancel D: {cancelled}\n")

# 等待所有任务完成
time.sleep(3)

print("\n=== Final Stats ===")
print(scheduler.get_progress())
print("Completed:", sorted(scheduler.completed))
print("Cancelled:", sorted(scheduler.cancelled_tasks))

scheduler.shutdown()
