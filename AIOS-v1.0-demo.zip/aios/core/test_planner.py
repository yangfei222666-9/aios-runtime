"""
AIOS Planning Module - Unit Tests

测试覆盖：
1. 简单任务识别
2. CoT 任务拆解（4种规则）
3. 任务类型推断
4. 优先级推断
5. 时间估算
6. 依赖分析
7. 执行策略选择
8. Plan 保存/加载
9. 状态更新

Author: 小九 + 珊瑚海
Date: 2026-02-26
"""

import unittest
import tempfile
import shutil
from pathlib import Path
import sys

# 导入 Planner
sys.path.insert(0, str(Path(__file__).parent))
from planner import Planner, Plan, SubTask


class TestPlanner(unittest.TestCase):
    """Planner 单元测试"""
    
    def setUp(self):
        """每个测试前创建临时工作目录"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.planner = Planner(self.temp_dir)
    
    def tearDown(self):
        """每个测试后清理临时目录"""
        shutil.rmtree(self.temp_dir)
    
    def test_simple_task_detection(self):
        """测试简单任务识别"""
        # 简单任务
        self.assertTrue(self.planner._is_simple_task("打开 QQ 音乐"))
        self.assertTrue(self.planner._is_simple_task("关闭浏览器"))
        self.assertTrue(self.planner._is_simple_task("查看文件"))
        
        # 复杂任务
        self.assertFalse(self.planner._is_simple_task("对比 AIOS 和标准 Agent 架构"))
        self.assertFalse(self.planner._is_simple_task("实现 Planning 模块并测试"))
    
    def test_task_type_inference(self):
        """测试任务类型推断"""
        self.assertEqual(self.planner._infer_task_type("写代码实现功能"), "code")
        self.assertEqual(self.planner._infer_task_type("分析系统架构"), "analysis")
        self.assertEqual(self.planner._infer_task_type("监控服务器状态"), "monitor")
        self.assertEqual(self.planner._infer_task_type("搜索相关资料"), "research")
        self.assertEqual(self.planner._infer_task_type("设计系统架构"), "design")
    
    def test_priority_inference(self):
        """测试优先级推断"""
        self.assertEqual(self.planner._infer_priority("紧急修复 bug"), "high")
        self.assertEqual(self.planner._infer_priority("立即处理"), "high")
        self.assertEqual(self.planner._infer_priority("可选功能"), "low")
        self.assertEqual(self.planner._infer_priority("有空再做"), "low")
        self.assertEqual(self.planner._infer_priority("实现功能"), "normal")
    
    def test_time_estimation(self):
        """测试时间估算"""
        # 开发任务
        time1 = self.planner._estimate_time("实现功能")
        self.assertGreaterEqual(time1, 600)
        
        # 分析任务
        time2 = self.planner._estimate_time("分析架构")
        self.assertGreaterEqual(time2, 180)
        
        # 搜索任务
        time3 = self.planner._estimate_time("搜索资料")
        self.assertGreaterEqual(time3, 120)
        
        # 长任务（超过50字会翻倍）
        time4 = self.planner._estimate_time("实现一个非常复杂的功能，需要考虑很多细节")
        self.assertGreaterEqual(time4, time1)  # 可能相等（都是600），也可能更大（1200）
    
    def test_simple_plan(self):
        """测试简单任务计划"""
        plan = self.planner.plan("打开 QQ 音乐")
        
        self.assertEqual(len(plan.subtasks), 1)
        self.assertEqual(plan.strategy, "sequential")
        self.assertEqual(plan.subtasks[0].description, "打开 QQ 音乐")
        self.assertEqual(len(plan.subtasks[0].dependencies), 0)
    
    def test_comparison_task_decomposition(self):
        """测试对比任务拆解"""
        plan = self.planner.plan("对比 AIOS 和标准 Agent 架构")
        
        # 应该拆解为 3 个子任务
        self.assertEqual(len(plan.subtasks), 3)
        
        # 第一个任务：收集 AIOS
        self.assertIn("AIOS", plan.subtasks[0].description)
        self.assertEqual(plan.subtasks[0].type, "research")
        self.assertEqual(len(plan.subtasks[0].dependencies), 0)
        
        # 第二个任务：收集标准 Agent
        self.assertIn("架构", plan.subtasks[1].description)
        self.assertEqual(plan.subtasks[1].type, "research")
        
        # 第三个任务：对比
        self.assertIn("对比", plan.subtasks[2].description)
        self.assertEqual(plan.subtasks[2].type, "analysis")
        self.assertEqual(len(plan.subtasks[2].dependencies), 2)
    
    def test_development_task_decomposition(self):
        """测试开发任务拆解"""
        plan = self.planner.plan("实现 Planning 模块")
        
        # 应该拆解为 3 个子任务：设计 → 实现 → 测试
        self.assertEqual(len(plan.subtasks), 3)
        
        # 第一个任务：设计
        self.assertIn("设计", plan.subtasks[0].description)
        self.assertEqual(plan.subtasks[0].type, "design")
        self.assertEqual(len(plan.subtasks[0].dependencies), 0)
        
        # 第二个任务：实现
        self.assertIn("实现", plan.subtasks[1].description)
        self.assertEqual(plan.subtasks[1].type, "code")
        self.assertIn("subtask_1", plan.subtasks[1].dependencies)
        
        # 第三个任务：测试
        self.assertIn("测试", plan.subtasks[2].description)
        self.assertEqual(plan.subtasks[2].type, "code")
        self.assertIn("subtask_2", plan.subtasks[2].dependencies)
    
    def test_connector_split(self):
        """测试连接词拆分"""
        plan = self.planner.plan("搜索资料，然后分析，最后写报告")
        
        # 应该拆解为 3 个子任务
        self.assertEqual(len(plan.subtasks), 3)
        
        # 检查依赖关系（顺序执行）
        self.assertEqual(len(plan.subtasks[0].dependencies), 0)
        self.assertIn("subtask_1", plan.subtasks[1].dependencies)
        self.assertIn("subtask_2", plan.subtasks[2].dependencies)
    
    def test_strategy_determination(self):
        """测试执行策略选择"""
        # 并行任务（无依赖）
        subtasks_parallel = [
            SubTask("1", "任务1", "code", "normal", [], 60),
            SubTask("2", "任务2", "code", "normal", [], 60)
        ]
        strategy1 = self.planner._determine_strategy(subtasks_parallel)
        self.assertEqual(strategy1, "parallel")
        
        # DAG 任务（复杂依赖）
        subtasks_dag = [
            SubTask("1", "任务1", "code", "normal", [], 60),
            SubTask("2", "任务2", "code", "normal", ["1"], 60),
            SubTask("3", "任务3", "code", "normal", ["1", "2"], 60)
        ]
        strategy2 = self.planner._determine_strategy(subtasks_dag)
        self.assertEqual(strategy2, "dag")
        
        # 顺序任务（简单依赖）
        subtasks_seq = [
            SubTask("1", "任务1", "code", "normal", [], 60),
            SubTask("2", "任务2", "code", "normal", ["1"], 60)
        ]
        strategy3 = self.planner._determine_strategy(subtasks_seq)
        self.assertEqual(strategy3, "sequential")
    
    def test_plan_save_load(self):
        """测试 Plan 保存和加载"""
        # 创建 Plan
        plan1 = self.planner.plan("实现功能")
        task_id = plan1.task_id
        
        # 加载 Plan
        plan2 = self.planner.load_plan(task_id)
        
        self.assertIsNotNone(plan2)
        self.assertEqual(plan2.task_id, plan1.task_id)
        self.assertEqual(plan2.original_task, plan1.original_task)
        self.assertEqual(len(plan2.subtasks), len(plan1.subtasks))
    
    def test_subtask_status_update(self):
        """测试子任务状态更新"""
        # 创建 Plan
        plan = self.planner.plan("实现功能")
        task_id = plan.task_id
        subtask_id = plan.subtasks[0].id
        
        # 更新状态
        self.planner.update_subtask_status(task_id, subtask_id, "completed", "成功")
        
        # 重新加载
        plan2 = self.planner.load_plan(task_id)
        self.assertEqual(plan2.subtasks[0].status, "completed")
        self.assertEqual(plan2.subtasks[0].result, "成功")
    
    def test_get_next_subtasks(self):
        """测试获取下一批可执行子任务"""
        # 创建有依赖的 Plan
        plan = self.planner.plan("实现 Planning 模块")
        task_id = plan.task_id
        
        # 初始状态：只有第一个任务可执行
        next_tasks = self.planner.get_next_subtasks(task_id)
        self.assertEqual(len(next_tasks), 1)
        self.assertEqual(next_tasks[0].id, "subtask_1")
        
        # 完成第一个任务
        self.planner.update_subtask_status(task_id, "subtask_1", "completed")
        
        # 现在第二个任务可执行
        next_tasks = self.planner.get_next_subtasks(task_id)
        self.assertEqual(len(next_tasks), 1)
        self.assertEqual(next_tasks[0].id, "subtask_2")
        
        # 完成第二个任务
        self.planner.update_subtask_status(task_id, "subtask_2", "completed")
        
        # 现在第三个任务可执行
        next_tasks = self.planner.get_next_subtasks(task_id)
        self.assertEqual(len(next_tasks), 1)
        self.assertEqual(next_tasks[0].id, "subtask_3")


def run_tests():
    """运行所有测试"""
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestPlanner)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 输出结果
    print("\n" + "="*70)
    print(f"测试总数: {result.testsRun}")
    print(f"成功: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
