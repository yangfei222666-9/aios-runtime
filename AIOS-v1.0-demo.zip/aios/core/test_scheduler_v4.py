"""
测试 Scheduler v4.0 - Planning + Memory + Tools 协同工作
"""
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from scheduler import Scheduler

# 创建 Scheduler（集成 Planning + Memory + Tools）
scheduler = Scheduler(workspace=Path(__file__).parent.parent)

print("=== AIOS v1.3 - 三大模块协同测试 ===\n")

# 测试任务：旅行规划
task = "帮我规划一次周末去京都的旅行，预算5000元"

print(f"📝 任务: {task}\n")

# 调度任务（自动拆解 + 记忆检索 + 工具执行）
plan_id = scheduler.schedule_with_planning(
    task,
    use_memory=True,   # 启用记忆检索
    use_tools=True     # 启用工具自动执行
)

print(f"✅ Plan ID: {plan_id}")
print(f"等待任务完成...\n")

# 等待所有任务完成
time.sleep(3)

# 获取 Plan 状态
status = scheduler.get_plan_status(plan_id)

print("\n=== 执行结果 ===")
print(f"总任务数: {status['total']}")
print(f"已完成: {status['completed']}")
print(f"进行中: {status['running']}")
print(f"待执行: {status['pending']}")
print(f"失败: {status['failed']}")

print("\n=== 子任务详情 ===")
for subtask in status['subtasks']:
    status_emoji = {
        'completed': '✅',
        'running': '🔄',
        'pending': '⏳',
        'failed': '❌'
    }.get(subtask['status'], '❓')
    
    print(f"{status_emoji} {subtask['description']}")
    if subtask.get('result'):
        print(f"   结果: {subtask['result']}")

# 工具使用统计
print("\n=== 工具使用统计 ===")
tool_stats = scheduler.tools.get_tool_stats()
print(f"总执行次数: {tool_stats['total_executions']}")
print(f"成功率: {tool_stats['total_successes'] / max(tool_stats['total_executions'], 1) * 100:.1f}%")

print("\n各工具统计:")
for tool_stat in tool_stats['tools']:
    if tool_stat['usage_count'] > 0:
        print(f"  {tool_stat['name']}: "
              f"{tool_stat['usage_count']} 次, "
              f"成功率 {tool_stat['success_rate']:.1%}")

# 记忆统计
print("\n=== 记忆统计 ===")
memory_stats = scheduler.memory.get_stats()
print(f"短期记忆: {memory_stats['short_term_count']} 条")
print(f"长期记忆: {memory_stats['long_term_count']} 条")
print(f"工作记忆: {memory_stats['working_memory_count']} 条")

print("\n✅ 测试完成！")
