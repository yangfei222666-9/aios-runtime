"""最简单的测试"""
import time
from scheduler_v2_1 import Scheduler

print("Creating scheduler...")
scheduler = Scheduler(max_concurrent=2)

print("Defining task...")
def task():
    print("Task running...")
    time.sleep(0.1)
    print("Task done")
    return "success"

print("Scheduling task...")
task_id = scheduler.schedule({"id": "test", "func": task})

print(f"Task {task_id} scheduled, waiting...")
time.sleep(1.0)

print(f"Completed: {scheduler.completed}")
print(f"Stats: {scheduler.get_stats()}")

print("Shutting down...")
scheduler.shutdown(wait=False)

print("Done!")
