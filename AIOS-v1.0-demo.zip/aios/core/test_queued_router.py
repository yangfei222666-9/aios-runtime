"""
Test: QueuedRouter integration with LLMQueue + ModelRouter
"""
import sys
import time
import threading
from pathlib import Path

AIOS_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIOS_ROOT))

from core.queued_router import QueuedRouter

passed = 0
failed = 0

def test(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed += 1
        print(f"  FAIL  {name}")

print("=" * 60)
print("QueuedRouter Integration Tests")
print("=" * 60)

# 1. Basic route
router = QueuedRouter(max_concurrency=2)
router.start()

result = router.route(
    task_type="summarize_short",
    prompt="Test prompt",
    priority="normal",
    agent_id="test-agent",
    timeout_sec=10.0,
)
test("Basic route: returns result", result is not None)
test("Basic route: has success field", "success" in result)
test("Basic route: has queue_wait_ms", "queue_wait_ms" in result)
test("Basic route: has queue_request_id", "queue_request_id" in result)

# 2. Priority ordering
results = []
lock = threading.Lock()

def route_and_record(priority, name):
    r = router.route(
        task_type="reasoning",
        prompt=f"Test {name}",
        priority=priority,
        agent_id=name,
        timeout_sec=10.0,
    )
    with lock:
        results.append({"name": name, "result": r})

threads = []
for p, n in [("low", "low_task"), ("high", "high_task"), ("normal", "normal_task")]:
    t = threading.Thread(target=route_and_record, args=(p, n))
    threads.append(t)
    t.start()

for t in threads:
    t.join(timeout=15)

test("Concurrent: all 3 completed", len(results) == 3)
test("Concurrent: all successful", all(r["result"].get("success") for r in results))

# 3. Stats
stats = router.stats()
test("Stats: has queue field", stats.get("queue") == "llm")
test("Stats: total_enqueued >= 4", stats["total_enqueued"] >= 4)
test("Stats: total_completed >= 4", stats["total_completed"] >= 4)

# 4. Agent ID tracking
result2 = router.route(
    task_type="simple_qa",
    prompt="Who?",
    agent_id="coder-001",
    timeout_sec=10.0,
)
test("Agent ID: tracked in result", result2.get("queue_agent_id") == "coder-001")

router.stop()

# Summary
print("\n" + "=" * 60)
total = passed + failed
print(f"Results: {passed}/{total} PASS, {failed}/{total} FAIL")
if failed == 0:
    print("ALL TESTS PASSED!")
print("=" * 60)

sys.exit(0 if failed == 0 else 1)
