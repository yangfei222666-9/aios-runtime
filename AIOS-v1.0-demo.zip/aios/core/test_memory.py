"""
AIOS Memory Module - Unit Tests

测试覆盖：
1. 记忆存储（短期/长期）
2. 向量检索
3. 工作记忆
4. 重要性计算
5. 记忆整理
6. 统计信息

Author: 小九 + 珊瑚海
Date: 2026-02-26
"""

import unittest
import tempfile
import shutil
from pathlib import Path
import sys
import time

# 导入 Memory
sys.path.insert(0, str(Path(__file__).parent))
from memory import MemoryManager, Memory, SimpleEmbedding, VectorDB


class TestSimpleEmbedding(unittest.TestCase):
    """SimpleEmbedding 单元测试"""
    
    def test_fit_and_encode(self):
        """测试训练和编码"""
        embedding = SimpleEmbedding(dim=64)
        texts = [
            "实现了 Planning 模块",
            "设计了 Memory 模块",
            "修复了一个 bug"
        ]
        
        # 训练
        embedding.fit(texts)
        
        # 编码
        vec1 = embedding.encode("Planning 模块")
        vec2 = embedding.encode("Memory 模块")
        
        self.assertEqual(len(vec1), 64)
        self.assertEqual(len(vec2), 64)
        
        # 向量应该不同
        self.assertNotEqual(vec1, vec2)
    
    def test_tokenize(self):
        """测试分词"""
        embedding = SimpleEmbedding()
        tokens = embedding._tokenize("Hello, World! This is a test.")
        
        self.assertIn("hello", tokens)
        self.assertIn("world", tokens)
        self.assertIn("test", tokens)


class TestVectorDB(unittest.TestCase):
    """VectorDB 单元测试"""
    
    def setUp(self):
        """每个测试前创建临时目录"""
        self.temp_dir = Path(tempfile.mkdtemp())
    
    def tearDown(self):
        """每个测试后清理临时目录"""
        shutil.rmtree(self.temp_dir)
    
    def test_add_and_search(self):
        """测试添加和检索"""
        db = VectorDB(dim=64)
        
        # 添加向量
        mem1 = Memory(
            id="1", content="Planning 模块", type="long_term",
            importance=0.9, timestamp=time.time(), source="user", metadata={}
        )
        mem2 = Memory(
            id="2", content="Memory 模块", type="long_term",
            importance=0.9, timestamp=time.time(), source="user", metadata={}
        )
        
        vec1 = [0.1] * 64
        vec2 = [0.2] * 64
        
        db.add(vec1, mem1)
        db.add(vec2, mem2)
        
        # 检索
        results = db.search([0.15] * 64, k=2)
        
        self.assertEqual(len(results), 2)
    
    def test_save_and_load(self):
        """测试保存和加载"""
        db = VectorDB(dim=64)
        
        # 添加数据
        mem = Memory(
            id="1", content="Test", type="long_term",
            importance=0.9, timestamp=time.time(), source="user", metadata={}
        )
        db.add([0.1] * 64, mem)
        
        # 保存
        db_file = self.temp_dir / "test.json"
        db.save(db_file)
        
        # 加载
        db2 = VectorDB(dim=64)
        db2.load(db_file)
        
        self.assertEqual(len(db2.memories), 1)
        self.assertEqual(db2.memories[0].content, "Test")


class TestMemoryManager(unittest.TestCase):
    """MemoryManager 单元测试"""
    
    def setUp(self):
        """每个测试前创建临时工作目录"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.manager = MemoryManager(self.temp_dir, dim=64)
    
    def tearDown(self):
        """每个测试后清理临时目录"""
        shutil.rmtree(self.temp_dir)
    
    def test_store_short_term(self):
        """测试短期记忆存储"""
        mem = self.manager.store("这是一条短期记忆", importance=0.5)
        
        self.assertEqual(mem.type, "short_term")
        self.assertEqual(len(self.manager.short_term), 1)
    
    def test_store_long_term(self):
        """测试长期记忆存储"""
        mem = self.manager.store("这是一条重要的长期记忆", importance=0.9)
        
        self.assertEqual(mem.type, "long_term")
        self.assertGreater(len(self.manager.long_term.memories), 0)
    
    def test_retrieve(self):
        """测试记忆检索"""
        # 存储记忆
        self.manager.store("实现了 Planning 模块", importance=0.9)
        self.manager.store("设计了 Memory 模块", importance=0.9)
        self.manager.store("修复了一个 bug", importance=0.3)
        
        # 检索
        results = self.manager.retrieve("Planning 模块", k=2)
        
        self.assertGreater(len(results), 0)
        # 第一个结果应该包含 "Planning"
        self.assertIn("Planning", results[0].content)
    
    def test_working_memory(self):
        """测试工作记忆"""
        task_id = "task_123"
        
        # 存储工作记忆
        self.manager.store_working(task_id, "开始任务")
        self.manager.store_working(task_id, "完成任务")
        
        # 获取工作记忆
        working_mems = self.manager.get_working(task_id)
        
        self.assertEqual(len(working_mems), 2)
        self.assertEqual(working_mems[0].content, "开始任务")
        
        # 清理工作记忆
        self.manager.clear_working(task_id)
        self.assertEqual(len(self.manager.get_working(task_id)), 0)
    
    def test_importance_calculation(self):
        """测试重要性计算"""
        # 短文本
        importance1 = self.manager._calculate_importance("短文本")
        
        # 长文本
        long_text = "这是一段很长的文本" * 50
        importance2 = self.manager._calculate_importance(long_text)
        
        # 包含关键词
        importance3 = self.manager._calculate_importance("这是一个重要的决策")
        
        self.assertLess(importance1, importance2)
        self.assertGreater(importance3, importance1)
    
    def test_consolidate(self):
        """测试记忆整理"""
        # 存储一些记忆
        self.manager.store("重要记忆1", importance=0.9)
        self.manager.store("重要记忆2", importance=0.9)
        self.manager.store("不重要记忆", importance=0.3)
        
        initial_long_term = len(self.manager.long_term.memories)
        
        # 整理
        self.manager.consolidate()
        
        # 长期记忆应该增加（重要的短期记忆被持久化）
        self.assertGreaterEqual(len(self.manager.long_term.memories), initial_long_term)
    
    def test_stats(self):
        """测试统计信息"""
        # 存储一些记忆
        self.manager.store("记忆1", importance=0.9)
        self.manager.store("记忆2", importance=0.5)
        
        stats = self.manager.get_stats()
        
        self.assertIn("short_term_count", stats)
        self.assertIn("long_term_count", stats)
        self.assertIn("total_memories", stats)
        self.assertGreater(stats["total_memories"], 0)
    
    def test_short_term_limit(self):
        """测试短期记忆限制"""
        # 存储 150 条记忆（超过限制 100）
        for i in range(150):
            self.manager.store(f"记忆 {i}", importance=0.3)
        
        # 短期记忆应该被限制在 100 条
        self.assertLessEqual(len(self.manager.short_term), 100)


def run_tests():
    """运行所有测试"""
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    suite.addTests(loader.loadTestsFromTestCase(TestSimpleEmbedding))
    suite.addTests(loader.loadTestsFromTestCase(TestVectorDB))
    suite.addTests(loader.loadTestsFromTestCase(TestMemoryManager))
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 输出结果
    print("\n" + "="*70)
    print(f"测试总数: {result.testsRun}")
    print(f"成功: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"失败: {len(result.failures)}")
    print(f"错误: {len(result.errors)}")
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
